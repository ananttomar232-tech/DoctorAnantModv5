package com.dranant;

import com.dranant.command.ModCommands;
import com.dranant.config.DrAnantConfig;
import com.dranant.entity.*;
import com.dranant.network.BankPayload;
import com.dranant.network.CarControlPayload;
import com.dranant.network.SpeechPayload;
import com.dranant.registry.*;
import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import org.slf4j.Logger;

@Mod(DoctorAnantMod.MODID)
public class DoctorAnantMod {
    public static final String MODID = "dranant";
    public static final Logger LOGGER = LogUtils.getLogger();

    public DoctorAnantMod(IEventBus modBus, ModContainer container) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        ModEffects.MOB_EFFECTS.register(modBus);
        ModSounds.SOUNDS.register(modBus);
        ModArmorMaterials.ARMOR_MATERIALS.register(modBus);

        modBus.addListener(this::onEntityAttributes);
        modBus.addListener(this::onRegisterPayloads);
        NeoForge.EVENT_BUS.addListener(this::onRegisterCommands);

        container.registerConfig(ModConfig.Type.COMMON, DrAnantConfig.SPEC);
        LOGGER.info("Doctor Anant's Mega Clinic & Mutant Siege V5 initialized!");
    }

    private void onEntityAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.PATIENT_VILLAGER.get(), PatientVillagerEntity.createAttributes().build());
        event.put(ModEntities.SHOPKEEPER.get(), ShopkeeperEntity.createAttributes().build());
        event.put(ModEntities.ASSISTANT_PHARMACIST.get(), AssistantPharmacistEntity.createAttributes().build());
        event.put(ModEntities.ASSISTANT_SCIENTIST.get(), AssistantScientistEntity.createAttributes().build());
        event.put(ModEntities.SIDEKICK.get(), SidekickEntity.createAttributes().build());
        event.put(ModEntities.MUTANT_BLOOD_BEAST.get(), MutantBloodBeastEntity.createAttributes().build());
        event.put(ModEntities.FACTORY_GUARD.get(), FactoryGuardEntity.createAttributes().build());
        event.put(ModEntities.DRIVER_VILLAGER.get(), DriverVillagerEntity.createAttributes().build());
        event.put(ModEntities.CUSTOMER_VILLAGER.get(), CustomerVillagerEntity.createAttributes().build());
        event.put(ModEntities.CONSULTATION_VILLAGER.get(), ConsultationVillagerEntity.createAttributes().build());
        event.put(ModEntities.HOSPITAL_BED_VILLAGER.get(), HospitalBedVillagerEntity.createAttributes().build());
    }

    private void onRegisterPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar(MODID);
        registrar.playToClient(SpeechPayload.TYPE, SpeechPayload.STREAM_CODEC, SpeechPayload::handle);
        registrar.playToClient(BankPayload.TYPE, BankPayload.STREAM_CODEC, BankPayload::handle);
        registrar.playToServer(CarControlPayload.TYPE, CarControlPayload.STREAM_CODEC, CarControlPayload::handle);
    }

    private void onRegisterCommands(RegisterCommandsEvent event) {
        ModCommands.register(event.getDispatcher());
    }

    public static ResourceLocation id(String path) {
        return ResourceLocation.fromNamespaceAndPath(MODID, path);
    }
}
