package com.dranant.shop;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.core.BlockPos;

public class PreviewManager {
    private static final Map<UUID, BlockPos> PENDING = new HashMap<>();

    public static boolean isConfirming(UUID player, BlockPos pos) {
        return pos.equals(PENDING.get(player));
    }

    public static void start(UUID player, BlockPos pos) {
        PENDING.put(player, pos);
    }

    public static void clear(UUID player) {
        PENDING.remove(player);
    }
}
