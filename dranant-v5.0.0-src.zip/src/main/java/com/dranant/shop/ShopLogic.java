package com.dranant.shop;

import com.dranant.block.entity.ItemDisplayPedestalBlockEntity;
import com.dranant.clinic.BuildHelper;
import com.dranant.clinic.ClinicBuilder;
import com.dranant.clinic.ClinicTiers;
import com.dranant.counter.DiamondBank;
import com.dranant.counter.DiamondFx;
import com.dranant.dialogue.Lines;
import com.dranant.dialogue.Speech;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

public class ShopLogic {
    public static long defaultPrice(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        return 10;
    }

    public static long funds(Player player) {
        long count = 0;
        for (ItemStack st : player.getInventory().items) {
            if (st.is(Items.DIAMOND)) count += st.getCount();
            else if (st.is(Items.DIAMOND_BLOCK)) count += (long)st.getCount() * 9;
        }
        return count;
    }

    public static boolean pay(Player player, long amount) {
        if (funds(player) < amount) return false;
        long needed = amount;
        for (ItemStack st : player.getInventory().items) {
            if (st.is(Items.DIAMOND)) {
                int take = (int)Math.min(needed, st.getCount());
                st.shrink(take);
                needed -= take;
                if (needed <= 0) break;
            }
        }
        if (needed > 0) {
            for (ItemStack st : player.getInventory().items) {
                if (st.is(Items.DIAMOND_BLOCK)) {
                    int blocksNeeded = (int)Math.ceil((double)needed / 9.0);
                    int takeBlocks = Math.min(blocksNeeded, st.getCount());
                    st.shrink(takeBlocks);
                    long given = takeBlocks * 9L;
                    long change = given - needed;
                    if (change > 0) {
                        player.getInventory().add(new ItemStack(Items.DIAMOND, (int)change));
                    }
                    needed = 0;
                    break;
                }
            }
        }
        return true;
    }

    public static void purchase(ServerLevel level, BlockPos pos, Player player, ItemDisplayPedestalBlockEntity pedestal) {
        long price = pedestal.getPrice();
        ItemStack item = pedestal.getItem();
        if (item.isEmpty()) {
            player.sendSystemMessage(Component.literal("§cThis pedestal is empty."));
            return;
        }

        if (pay(player, price)) {
            ItemStack give = item.copy();
            if (!player.getInventory().add(give)) {
                player.drop(give, false);
            }
            DiamondFx.burst(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
            player.sendSystemMessage(Component.literal("§aPurchased " + item.getHoverName().getString() + " for " + price + " Diamonds!"));
            DiamondBank.get(level.getServer()).add(price, level.getServer());
        } else {
            notEnough(level, pos, player, price);
        }
    }

    public static void notEnough(ServerLevel level, BlockPos pos, Player player, long price) {
        player.sendSystemMessage(Component.literal("§cYou need " + price + " Diamonds (you have " + funds(player) + ")"));
    }
}
