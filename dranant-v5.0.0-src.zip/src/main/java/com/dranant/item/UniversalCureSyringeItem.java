package com.dranant.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

public class UniversalCureSyringeItem extends Item {
    public UniversalCureSyringeItem(Properties properties) { super(properties); }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§dUniversal Cure Syringe"));
        tooltip.add(Component.literal("§7Instantly cures any illness or mutation."));
    }
}
