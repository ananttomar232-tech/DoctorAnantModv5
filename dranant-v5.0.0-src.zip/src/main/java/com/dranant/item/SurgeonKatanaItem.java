package com.dranant.item;

import java.util.List;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tiers;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class SurgeonKatanaItem extends SwordItem {
    public SurgeonKatanaItem(Properties properties) {
        super(Tiers.NETHERITE, properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.getCooldowns().addCooldown(this, 60); // 3s cooldown

        Vec3 look = player.getViewVector(1.0f);
        Vec3 dash = look.scale(1.8);
        player.setDeltaMovement(dash.x, 0.35, dash.z);
        player.hurtMarked = true;

        if (level instanceof ServerLevel sl) {
            Vec3 pos = player.position();
            AABB pathBox = player.getBoundingBox().expandTowards(look.scale(8.0)).inflate(1.2);
            for (LivingEntity e : sl.getEntitiesOfClass(LivingEntity.class, pathBox, target -> target != player && target.isAlive())) {
                e.hurt(sl.damageSources().playerAttack(player), 10.0f);
            }
            sl.sendParticles(ParticleTypes.SWEEP_ATTACK, pos.x, pos.y + 1.0, pos.z, 8, 0.5, 0.5, 0.5, 0.1);
            sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.0f, 1.4f);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§dRight-click: Scalpel Dash (8 blocks, 10 dmg)"));
        tooltip.add(Component.literal("§73s cooldown - Dash out of heavy attacks!"));
    }
}
