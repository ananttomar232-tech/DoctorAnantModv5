package com.dranant.item;

import com.dranant.entity.MutantBloodBeastEntity;
import com.dranant.entity.SidekickEntity;
import com.dranant.registry.ModSounds;
import java.util.List;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

public class PlasmaRifleItem extends Item {
    public static final double RANGE = 48.0;
    public static final float DAMAGE = 24.0f; // UPGRADED for v5
    public static final int COOLDOWN = 10;

    public PlasmaRifleItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.getCooldowns().addCooldown(this, COOLDOWN);

        if (level instanceof ServerLevel sl) {
            fire(sl, player);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    private void fire(ServerLevel level, Player player) {
        Vec3 eyePos = player.getEyePosition();
        Vec3 lookVec = player.getViewVector(1.0f);
        Vec3 traceEnd = eyePos.add(lookVec.scale(RANGE));

        BlockHitResult bHit = level.clip(new ClipContext(eyePos, traceEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        Vec3 hitPos = bHit.getType() != HitResult.Type.MISS ? bHit.getLocation() : traceEnd;

        AABB box = player.getBoundingBox().expandTowards(lookVec.scale(RANGE)).inflate(1.5);
        EntityHitResult eHit = ProjectileUtil.getEntityHitResult(level, player, eyePos, hitPos, box, e ->
            e instanceof LivingEntity le && le.isAlive() && le != player && !le.isAlliedTo(player) && !(le instanceof SidekickEntity)
        );

        if (eHit != null) {
            hitPos = eHit.getLocation();
            Entity target = eHit.getEntity();
            float dmg = DAMAGE;
            if (target instanceof MutantBloodBeastEntity) {
                // x2 back damage
                Vec3 toTarget = target.position().subtract(player.position()).normalize();
                Vec3 targetLook = target.getViewVector(1.0f);
                if (toTarget.dot(targetLook) > 0.3) {
                    dmg *= 2.0f;
                    level.sendParticles(ParticleTypes.CRIT, hitPos.x, hitPos.y, hitPos.z, 15, 0.2, 0.2, 0.2, 0.1);
                }
            }
            target.hurt(level.damageSources().playerAttack(player), dmg);
        }

        // Plasma beam particle trace
        int steps = (int)(eyePos.distanceTo(hitPos) * 3);
        Vec3 stepVec = hitPos.subtract(eyePos).scale(1.0 / Math.max(1, steps));
        DustParticleOptions plasmaCyan = new DustParticleOptions(new Vector3f(0.1f, 0.9f, 1.0f), 1.2f);
        Vec3 cur = eyePos;
        for (int i = 0; i < steps; i++) {
            cur = cur.add(stepVec);
            level.sendParticles(plasmaCyan, cur.x, cur.y, cur.z, 1, 0, 0, 0, 0);
        }

        level.playSound(null, player.getX(), player.getY(), player.getZ(), ModSounds.MACHINE_GUN_FIRE.get(), SoundSource.PLAYERS, 1.0f, 1.5f);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§bRight-click: High-Power Plasma Beam (48 blocks, 24 dmg)"));
        tooltip.add(Component.literal("§cBack-shots on Mutant Blood Beast deal x2 (48 dmg)"));
        tooltip.add(Component.literal("§aUsable while riding supercars or superbikes"));
    }

    @Override
    public boolean isEnchantable(ItemStack stack) { return false; }
}
