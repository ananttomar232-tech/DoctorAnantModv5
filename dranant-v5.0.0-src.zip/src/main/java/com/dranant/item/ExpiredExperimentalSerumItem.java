package com.dranant.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

public class ExpiredExperimentalSerumItem extends Item {
    public ExpiredExperimentalSerumItem(Properties properties) { super(properties); }

    @Override
    public boolean isFoil(ItemStack stack) { return true; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§cWARNING: Highly Unstable Serum"));
        tooltip.add(Component.literal("§4Causes terrifying biological mutations if released!"));
    }
}
