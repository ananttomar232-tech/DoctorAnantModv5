package com.dranant.item;

import com.dranant.registry.ModArmorMaterials;
import java.util.List;
import net.minecraft.core.Holder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ArmorItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class DrAnantCoatItem extends ArmorItem {
    public DrAnantCoatItem(Properties properties) {
        super(ModArmorMaterials.DR_ANANT_COAT, ArmorItem.Type.CHESTPLATE, properties);
    }

    @Override
    public void inventoryTick(ItemStack stack, Level level, Entity entity, int slotId, boolean isSelected) {
        super.inventoryTick(stack, level, entity, slotId, isSelected);
        if (!level.isClientSide() && entity instanceof Player player) {
            if (player.getItemBySlot(EquipmentSlot.CHEST) == stack) {
                player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false, true));
                player.addEffect(new MobEffectInstance(MobEffects.SATURATION, 40, 0, false, false, true));
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§eWorn by the great Dr. Anant"));
        tooltip.add(Component.literal("§bResistance I + Saturation while worn"));
    }
}
