package com.dranant.item;

import com.dranant.entity.SidekickEntity;
import com.dranant.registry.ModEntities;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

public class SidekickWhistleItem extends Item {
    public SidekickWhistleItem(Properties properties) { super(properties); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.getCooldowns().addCooldown(this, 100);

        if (level instanceof ServerLevel sl) {
            sl.playSound(null, player.getX(), player.getY(), player.getZ(), SoundEvents.ARROW_HIT_PLAYER, SoundSource.PLAYERS, 1.2f, 1.8f);
            List<SidekickEntity> list = sl.getEntitiesOfClass(SidekickEntity.class, player.getBoundingBox().inflate(64.0), s -> player.getUUID().equals(s.getOwnerId()));
            if (list.isEmpty()) {
                SidekickEntity sidekick = new SidekickEntity(ModEntities.SIDEKICK.get(), sl);
                sidekick.setPos(player.getX() + 1.0, player.getY(), player.getZ() + 1.0);
                sidekick.setOwner(player);
                sl.addFreshEntity(sidekick);
                player.sendSystemMessage(Component.literal("§a[Sidekick] Agent summoned to assist you!"));
            } else {
                SidekickEntity s = list.get(0);
                s.teleportTo(player.getX() + 1.0, player.getY(), player.getZ() + 1.0);
                player.sendSystemMessage(Component.literal("§a[Sidekick] Agent rallied to your side!"));
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§6Calls your tactical agent sidekick"));
        tooltip.add(Component.literal("§7Rides with you and covers you in combat"));
    }
}
