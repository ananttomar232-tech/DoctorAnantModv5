package com.dranant.item;

import com.dranant.registry.ModEffects;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

public class MedicineItem extends Item {
    private final int tier;

    public MedicineItem(Properties properties, int tier) {
        super(properties);
        this.tier = tier;
    }

    public int getTier() { return tier; }
    public long getShopPrice() { return 5L * tier; }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) { return 32; }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) { return UseAnim.DRINK; }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        return ItemUtils.startUsingInstantly(level, player, hand);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity consumer) {
        if (!level.isClientSide()) {
            applyMedicine(consumer);
        }
        if (consumer instanceof Player player && !player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        return stack;
    }

    private void applyMedicine(LivingEntity entity) {
        entity.removeAllEffects();
        switch (tier) {
            case 1 -> {
                entity.heal(4.0f);
                entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 0));
            }
            case 2 -> {
                entity.heal(8.0f);
                entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 400, 1));
                entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 600, 0));
            }
            case 3 -> {
                entity.heal(14.0f);
                entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 600, 2));
                entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 600, 1));
                entity.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 1200, 1));
            }
            case 4 -> {
                entity.heal(20.0f);
                entity.addEffect(new MobEffectInstance(ModEffects.IMMORTALITY, 600, 0)); // 30s immortality!
                entity.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 1200, 2));
            }
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§6Tier " + tier + " Dr. Anant Medicine"));
        tooltip.add(Component.literal("§7Cures ailments, restores health & grants buffs."));
    }
}
