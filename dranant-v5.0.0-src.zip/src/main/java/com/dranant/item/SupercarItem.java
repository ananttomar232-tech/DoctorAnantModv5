package com.dranant.item;

import com.dranant.entity.SupercarEntity;
import com.dranant.entity.SupercarVariant;
import com.dranant.registry.ModEntities;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;

public class SupercarItem extends Item {
    private final SupercarVariant variant;

    public SupercarItem(Properties properties, SupercarVariant variant) {
        super(properties);
        this.variant = variant;
    }

    public SupercarVariant getVariant() { return variant; }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel() instanceof ServerLevel sl) {
            BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
            SupercarEntity car = new SupercarEntity(ModEntities.SUPERCAR.get(), sl, variant);
            car.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            car.setYRot(context.getPlayer() != null ? context.getPlayer().getYRot() : 0);
            sl.addFreshEntity(car);
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(context.getLevel().isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§c" + variant.getDisplayName()));
        tooltip.add(Component.literal("§7Max Speed: §f" + (int)variant.getMaxSpeed() + " km/h"));
        tooltip.add(Component.literal("§7Realistic Gearbox, Modes & Doors!"));
    }
}
