package com.dranant.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

public class TitaniumHandcuffsItem extends Item {
    public TitaniumHandcuffsItem(Properties properties) { super(properties); }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§8High-Strength Titanium Handcuffs"));
        tooltip.add(Component.literal("§7Restrains aggressive patients or intruders."));
    }
}
