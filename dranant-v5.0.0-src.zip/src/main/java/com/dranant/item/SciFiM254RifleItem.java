package com.dranant.item;

import com.dranant.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public class SciFiM254RifleItem extends Item {
    public SciFiM254RifleItem() {
        super(new Item.Properties().durability(1000).stacksTo(1));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        player.getCooldowns().addCooldown(this, 12); // Semi-auto sniper cooldown

        if (!level.isClientSide) {
            Vec3 start = player.getEyePosition();
            Vec3 look = player.getLookAngle();
            double range = 96.0;
            Vec3 end = start.add(look.scale(range));

            BlockHitResult bHit = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (bHit.getType() != HitResult.Type.MISS) {
                end = bHit.getLocation();
            }

            EntityHitResult eHit = ProjectileUtil.getEntityHitResult(level, player, start, end,
                    new AABB(start, end).inflate(1.5), e -> e instanceof LivingEntity && !e.isSpectator());

            if (eHit != null && eHit.getEntity() instanceof LivingEntity target) {
                target.hurt(level.damageSources().playerAttack(player), 95.0F); // Extreme Sci-Fi rifle damage!
                end = target.getEyePosition();
            }

            // Beam particle line
            if (level instanceof ServerLevel sl) {
                double dist = start.distanceTo(end);
                Vec3 dir = end.subtract(start).normalize();
                for (double d = 0.5; d < dist; d += 0.8) {
                    Vec3 pt = start.add(dir.scale(d));
                    sl.sendParticles(ParticleTypes.ELECTRIC_SPARK, pt.x, pt.y, pt.z, 1, 0, 0, 0, 0);
                }
            }

            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.SCIFI_RIFLE_SHOT.get(), SoundSource.PLAYERS, 1.5F, 1.0F);
            stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        }

        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
