package com.dranant.item;

import com.dranant.entity.SidekickBulletEntity;
import com.dranant.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class HeavyMachineGunItem extends Item {
    public HeavyMachineGunItem() {
        super(new Item.Properties().durability(1500).stacksTo(1));
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public int getUseDuration(ItemStack stack, LivingEntity entity) {
        return 72000;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(player.getItemInHand(hand));
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int count) {
        if (!level.isClientSide && entity instanceof Player player) {
            // Rapid full-auto firing (every 2 ticks = 10 rounds/sec)
            if (count % 2 == 0) {
                SidekickBulletEntity bullet = new SidekickBulletEntity(level, player);
                bullet.setBaseDamage(22.0); // High weapon damage!
                Vec3 look = player.getLookAngle();
                bullet.shoot(look.x, look.y, look.z, 3.8F, 1.2F);
                level.addFreshEntity(bullet);

                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        ModSounds.MACHINE_GUN_SHOT.get(), SoundSource.PLAYERS, 1.2F, 1.0F + (player.getRandom().nextFloat() - 0.5F) * 0.2F);

                if (level instanceof ServerLevel sl) {
                    Vec3 muzzle = player.getEyePosition().add(look.scale(0.8));
                    sl.sendParticles(ParticleTypes.SMOKE, muzzle.x, muzzle.y, muzzle.z, 2, 0.05, 0.05, 0.05, 0.01);
                }
                stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(player.getUsedItemHand()));
            }
        }
    }
}
