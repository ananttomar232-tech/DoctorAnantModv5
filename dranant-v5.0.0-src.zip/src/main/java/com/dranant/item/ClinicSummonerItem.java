package com.dranant.item;

import com.dranant.clinic.ClinicTiers;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.block.Block;

public class ClinicSummonerItem extends BlockItem {
    private final int tier;

    public ClinicSummonerItem(Block block, Properties properties, int tier) {
        super(block, properties);
        this.tier = tier;
    }

    public int getTier() { return tier; }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§aTier " + tier + ": " + ClinicTiers.name(tier)));
        tooltip.add(Component.literal("§7Place and right-click to construct!"));
    }
}
