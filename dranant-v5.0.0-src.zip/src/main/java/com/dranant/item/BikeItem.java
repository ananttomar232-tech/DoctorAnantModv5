package com.dranant.item;

import com.dranant.entity.BikeEntity;
import com.dranant.registry.ModEntities;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;

public class BikeItem extends Item {
    public BikeItem(Properties properties) { super(properties); }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (context.getLevel() instanceof ServerLevel sl) {
            BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
            BikeEntity bike = new BikeEntity(ModEntities.BIKE.get(), sl);
            bike.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            bike.setYRot(context.getPlayer() != null ? context.getPlayer().getYRot() : 0);
            sl.addFreshEntity(bike);
            context.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(context.getLevel().isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§6Veloce RR Superbike"));
        tooltip.add(Component.literal("§7High-speed superbike with realistic lean and throttle."));
    }
}
