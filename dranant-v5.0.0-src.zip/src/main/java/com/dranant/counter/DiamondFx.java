package com.dranant.counter;

import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import org.joml.Vector3f;

public class DiamondFx {
    private static final DustParticleOptions CYAN_DUST = new DustParticleOptions(new Vector3f(0.1f, 0.9f, 0.9f), 1.0f);
    private static final DustParticleOptions GOLD_DUST = new DustParticleOptions(new Vector3f(1.0f, 0.9f, 0.0f), 1.0f);

    public static void burst(ServerLevel level, double x, double y, double z) {
        int count = 28;
        for (int i = 0; i < count; i++) {
            double angle = 6.283185307179586 * i / count;
            double vx = Math.cos(angle) * 1.6;
            double vz = Math.sin(angle) * 1.6;
            double vy = 0.4 + level.random.nextDouble() * 0.8;
            DustParticleOptions p = (i % 2 == 0) ? CYAN_DUST : GOLD_DUST;
            level.sendParticles(p, x, y, z, 0, vx, vy, vz, 1.0);
        }
        level.sendParticles(ParticleTypes.HAPPY_VILLAGER, x, y + 0.2, z, 12, 0.35, 0.25, 0.35, 0.02);
        level.playSound(null, x, y, z, SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.9f, 1.1f + level.random.nextFloat() * 0.3f);
        level.playSound(null, x, y, z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 0.8f, 1.0f);
    }
}
