package com.dranant.counter;

import com.dranant.network.BankPayload;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.saveddata.SavedData;
import net.neoforged.neoforge.network.PacketDistributor;

public class DiamondBank extends SavedData {
    public static final String NAME = "dranant_diamond_bank";

    private long balance = 0;
    private boolean running = false;
    private boolean visible = true;
    private double runTime = 0.0;
    private double speed = 1.0;
    private double passiveCarry = 0.0;
    private int syncTimer = 0;

    public static DiamondBank get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
            new SavedData.Factory<>(DiamondBank::new, DiamondBank::load),
            NAME
        );
    }

    public static DiamondBank load(CompoundTag tag, HolderLookup.Provider provider) {
        DiamondBank bank = new DiamondBank();
        bank.balance = tag.getLong("balance");
        bank.running = tag.getBoolean("running");
        bank.visible = tag.contains("visible") ? tag.getBoolean("visible") : true;
        bank.runTime = tag.getDouble("runTime");
        bank.speed = tag.contains("speed") ? tag.getDouble("speed") : 1.0;
        return bank;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putLong("balance", balance);
        tag.putBoolean("running", running);
        tag.putBoolean("visible", visible);
        tag.putDouble("runTime", runTime);
        tag.putDouble("speed", speed);
        return tag;
    }

    public long getBalance() { return balance; }

    public void add(long amount, MinecraftServer server) {
        this.balance += amount;
        setDirty();
        sync(server, amount);
    }

    public boolean pay(long amount, MinecraftServer server) {
        if (this.balance >= amount) {
            this.balance -= amount;
            setDirty();
            sync(server, -amount);
            return true;
        }
        return false;
    }

    public void setRunning(boolean running, MinecraftServer server) {
        this.running = running;
        setDirty();
        sync(server, 0);
    }

    public void setSpeed(MinecraftServer server, double speed) {
        this.speed = Math.max(0.1, speed);
        setDirty();
        sync(server, 0);
    }

    public double getSpeed() { return speed; }
    public boolean isRunning() { return running; }
    public boolean isVisible() { return visible; }

    public double currentRatePerSecond() {
        return running ? speed * 5.0 : 0.0;
    }

    public void sync(MinecraftServer server, long delta) {
        BankPayload payload = new BankPayload(balance, currentRatePerSecond(), running, visible, speed, delta);
        PacketDistributor.sendToAllPlayers(payload);
    }

    public void syncToPlayer(ServerPlayer player) {
        BankPayload payload = new BankPayload(balance, currentRatePerSecond(), running, visible, speed, 0);
        PacketDistributor.sendToPlayer(player, payload);
    }
}
