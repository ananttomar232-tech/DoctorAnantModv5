package com.dranant.counter;

import com.dranant.network.BankPayload;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ClientDiamondData {
    private static long balance = 0;
    private static double rate = 0;
    private static boolean running = false;
    private static boolean visible = true;
    private static double speed = 1.0;
    private static long lastUpdate = 0;
    private static double smoothBalance = 0;
    private static long lastAnimTime = 0;
    private static long lastDeltaTime = 0;

    public record Popup(long amount, long spawnTime, float xOffset) {}
    private static final List<Popup> popups = new ArrayList<>();

    public static void update(BankPayload payload) {
        balance = payload.balance();
        rate = payload.rate();
        running = payload.running();
        visible = payload.visible();
        speed = payload.speed();
        lastUpdate = System.currentTimeMillis();

        if (payload.delta() != 0) {
            popups.add(new Popup(payload.delta(), lastUpdate, (float)(Math.random() * 30.0 - 15.0)));
            if (popups.size() > 10) {
                popups.remove(0);
            }
            lastDeltaTime = lastUpdate;
        }

        if (smoothBalance == 0 || Math.abs(smoothBalance - balance) > Math.max(1000000.0, balance * 0.5)) {
            smoothBalance = balance;
        }
    }

    public static long displayValue() {
        long now = System.currentTimeMillis();
        double target = balance + (running ? (rate * Math.max(0, now - lastUpdate) / 1000.0) : 0);
        double dt = lastAnimTime == 0 ? 0.016 : Math.min(0.1, (now - lastAnimTime) / 1000.0);
        lastAnimTime = now;
        smoothBalance += (target - smoothBalance) * Math.min(1.0, dt * 10.0);
        if (Math.abs(target - smoothBalance) < 1.0) smoothBalance = target;
        return Math.max(0, Math.round(smoothBalance));
    }

    public static float pulse() {
        long dt = System.currentTimeMillis() - lastDeltaTime;
        if (dt > 400) return 0f;
        return 1f - (dt / 400f);
    }

    public static double getRate() { return running ? rate : 0; }
    public static double getSpeed() { return speed; }
    public static boolean isRunning() { return running; }
    public static boolean isVisible() { return visible; }

    public static List<Popup> getActivePopups() {
        long now = System.currentTimeMillis();
        Iterator<Popup> it = popups.iterator();
        while (it.hasNext()) {
            if (now - it.next().spawnTime() > 1800) it.remove();
        }
        return new ArrayList<>(popups);
    }
}
