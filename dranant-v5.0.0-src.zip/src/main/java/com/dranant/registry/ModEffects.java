package com.dranant.registry;

import com.dranant.DoctorAnantMod;
import com.dranant.effect.ImmortalityEffect;
import com.dranant.effect.StunnedEffect;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.effect.MobEffect;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEffects {
    public static final DeferredRegister<MobEffect> MOB_EFFECTS = DeferredRegister.create(Registries.MOB_EFFECT, DoctorAnantMod.MODID);

    public static final DeferredHolder<MobEffect, ImmortalityEffect> IMMORTALITY = MOB_EFFECTS.register("immortality", ImmortalityEffect::new);
    public static final DeferredHolder<MobEffect, StunnedEffect> STUNNED = MOB_EFFECTS.register("stunned", StunnedEffect::new);
}
