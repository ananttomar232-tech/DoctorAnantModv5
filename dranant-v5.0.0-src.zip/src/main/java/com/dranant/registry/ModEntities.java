package com.dranant.registry;

import com.dranant.DoctorAnantMod;
import com.dranant.entity.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(Registries.ENTITY_TYPE, DoctorAnantMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<AssistantPharmacistEntity>> ASSISTANT_PHARMACIST = ENTITIES.register("assistant_pharmacist",
            () -> EntityType.Builder.of(AssistantPharmacistEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("assistant_pharmacist"));

    public static final DeferredHolder<EntityType<?>, EntityType<AssistantScientistEntity>> ASSISTANT_SCIENTIST = ENTITIES.register("assistant_scientist",
            () -> EntityType.Builder.of(AssistantScientistEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("assistant_scientist"));

    public static final DeferredHolder<EntityType<?>, EntityType<ShopkeeperEntity>> SHOPKEEPER = ENTITIES.register("shopkeeper",
            () -> EntityType.Builder.of(ShopkeeperEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("shopkeeper"));

    public static final DeferredHolder<EntityType<?>, EntityType<PatientVillagerEntity>> PATIENT_VILLAGER = ENTITIES.register("patient_villager",
            () -> EntityType.Builder.of(PatientVillagerEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("patient_villager"));

    public static final DeferredHolder<EntityType<?>, EntityType<SidekickEntity>> SIDEKICK = ENTITIES.register("sidekick",
            () -> EntityType.Builder.of(SidekickEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("sidekick"));

    public static final DeferredHolder<EntityType<?>, EntityType<SidekickBulletEntity>> SIDEKICK_BULLET = ENTITIES.register("sidekick_bullet",
            () -> EntityType.Builder.<SidekickBulletEntity>of(SidekickBulletEntity::new, MobCategory.MISC).sized(0.25F, 0.25F).build("sidekick_bullet"));

    public static final DeferredHolder<EntityType<?>, EntityType<BikeEntity>> DR_ANANT_BIKE = ENTITIES.register("dr_anant_bike",
            () -> EntityType.Builder.<BikeEntity>of(BikeEntity::new, MobCategory.MISC).sized(1.2F, 1.1F).build("dr_anant_bike"));

    public static final DeferredHolder<EntityType<?>, EntityType<BloodBoulderEntity>> BLOOD_BOULDER = ENTITIES.register("blood_boulder",
            () -> EntityType.Builder.<BloodBoulderEntity>of(BloodBoulderEntity::new, MobCategory.MISC).sized(1.0F, 1.0F).build("blood_boulder"));

    public static final DeferredHolder<EntityType<?>, EntityType<BloodOrbEntity>> BLOOD_ORB = ENTITIES.register("blood_orb",
            () -> EntityType.Builder.<BloodOrbEntity>of(BloodOrbEntity::new, MobCategory.MISC).sized(0.5F, 0.5F).build("blood_orb"));

    public static final DeferredHolder<EntityType<?>, EntityType<SupercarEntity>> SUPERCAR = ENTITIES.register("supercar",
            () -> EntityType.Builder.<SupercarEntity>of(SupercarEntity::new, MobCategory.MISC).sized(2.4F, 1.05F).build("supercar"));

    public static final DeferredHolder<EntityType<?>, EntityType<SeatEntity>> SEAT = ENTITIES.register("seat",
            () -> EntityType.Builder.<SeatEntity>of(SeatEntity::new, MobCategory.MISC).sized(0.1F, 0.1F).build("seat"));

    public static final DeferredHolder<EntityType<?>, EntityType<MutantBloodBeastEntity>> MUTANT_BLOOD_BEAST = ENTITIES.register("mutant_blood_beast",
            () -> EntityType.Builder.of(MutantBloodBeastEntity::new, MobCategory.MONSTER).sized(2.2F, 3.4F).fireImmune().build("mutant_blood_beast"));

    // V5 New Entities
    public static final DeferredHolder<EntityType<?>, EntityType<FactoryGuardEntity>> FACTORY_GUARD = ENTITIES.register("factory_guard",
            () -> EntityType.Builder.of(FactoryGuardEntity::new, MobCategory.MONSTER).sized(0.6F, 1.95F).build("factory_guard"));

    public static final DeferredHolder<EntityType<?>, EntityType<FactoryBusterTntEntity>> FACTORY_BUSTER_TNT = ENTITIES.register("factory_buster_tnt",
            () -> EntityType.Builder.<FactoryBusterTntEntity>of(FactoryBusterTntEntity::new, MobCategory.MISC).sized(0.98F, 0.98F).fireImmune().build("factory_buster_tnt"));

    public static final DeferredHolder<EntityType<?>, EntityType<CityTrafficVehicleEntity>> CITY_TRAFFIC_VEHICLE = ENTITIES.register("city_traffic_vehicle",
            () -> EntityType.Builder.<CityTrafficVehicleEntity>of(CityTrafficVehicleEntity::new, MobCategory.MISC).sized(2.2F, 1.4F).build("city_traffic_vehicle"));

    public static final DeferredHolder<EntityType<?>, EntityType<DriverVillagerEntity>> DRIVER_VILLAGER = ENTITIES.register("driver_villager",
            () -> EntityType.Builder.of(DriverVillagerEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("driver_villager"));

    public static final DeferredHolder<EntityType<?>, EntityType<CustomerVillagerEntity>> CUSTOMER_VILLAGER = ENTITIES.register("customer_villager",
            () -> EntityType.Builder.of(CustomerVillagerEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("customer_villager"));

    public static final DeferredHolder<EntityType<?>, EntityType<ConsultationVillagerEntity>> CONSULTATION_VILLAGER = ENTITIES.register("consultation_villager",
            () -> EntityType.Builder.of(ConsultationVillagerEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("consultation_villager"));

    public static final DeferredHolder<EntityType<?>, EntityType<HospitalBedVillagerEntity>> HOSPITAL_BED_VILLAGER = ENTITIES.register("hospital_bed_villager",
            () -> EntityType.Builder.of(HospitalBedVillagerEntity::new, MobCategory.CREATURE).sized(0.6F, 1.95F).build("hospital_bed_villager"));
}
