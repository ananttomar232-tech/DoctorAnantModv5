package com.dranant.registry;

import com.dranant.DoctorAnantMod;
import com.dranant.block.*;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.*;

public class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(DoctorAnantMod.MODID);
    public static final int CLINIC_TIERS = 6;
    public static final List<DeferredBlock<ClinicSummonerBlock>> CLINIC_SUMMONERS = new ArrayList<>();

    public static final DeferredBlock<CentralShopSpawnerBlock> CENTRAL_SHOP_SPAWNER = BLOCKS.register("central_shop_spawner",
            () -> new CentralShopSpawnerBlock(BlockBehaviour.Properties.of().strength(2.0F).sound(SoundType.METAL)));

    public static final DeferredBlock<ItemDisplayPedestalBlock> ITEM_DISPLAY_PEDESTAL = BLOCKS.register("item_display_pedestal",
            () -> new ItemDisplayPedestalBlock(BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().sound(SoundType.STONE)));

    public static final DeferredBlock<ExaminationBedBlock> EXAMINATION_BED = BLOCKS.register("examination_bed",
            () -> new ExaminationBedBlock(BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().sound(SoundType.METAL)));

    public static final DeferredBlock<DiamondCashRegisterBlock> DIAMOND_CASH_REGISTER = BLOCKS.register("diamond_cash_register",
            () -> new DiamondCashRegisterBlock(BlockBehaviour.Properties.of().strength(2.0F).noOcclusion().sound(SoundType.METAL)));

    public static final DeferredBlock<PosterLandscapeBlock> POSTER_LANDSCAPE = BLOCKS.register("poster_landscape",
            () -> new PosterLandscapeBlock(BlockBehaviour.Properties.of().strength(0.5F).noCollission().noOcclusion().sound(SoundType.WOOD)));

    public static final DeferredBlock<PosterSquareBlock> POSTER_SQUARE = BLOCKS.register("poster_square",
            () -> new PosterSquareBlock(BlockBehaviour.Properties.of().strength(0.5F).noCollission().noOcclusion().sound(SoundType.WOOD)));

    public static final DeferredBlock<PosterBillboardBlock> POSTER_BILLBOARD = BLOCKS.register("poster_billboard",
            () -> new PosterBillboardBlock(BlockBehaviour.Properties.of().strength(1.0F).noOcclusion().sound(SoundType.METAL)));

    public static final DeferredBlock<StretcherBlock> STRETCHER = BLOCKS.register("stretcher",
            () -> new StretcherBlock(BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().sound(SoundType.METAL)));

    public static final DeferredBlock<CityFounderBlock> CITY_FOUNDER = BLOCKS.register("city_founder",
            () -> new CityFounderBlock(BlockBehaviour.Properties.of().strength(3.0F).sound(SoundType.STONE)));

    // V5 New Blocks
    public static final DeferredBlock<FactoryBusterTntBlock> FACTORY_BUSTER_TNT = BLOCKS.register("factory_buster_tnt",
            () -> new FactoryBusterTntBlock(BlockBehaviour.Properties.of().strength(1.0F).sound(SoundType.GRASS)));

    public static final Map<FurnitureType, DeferredBlock<Block>> FURNITURE = new EnumMap<>(FurnitureType.class);

    static {
        for (int i = 1; i <= CLINIC_TIERS; i++) {
            final int tier = i;
            CLINIC_SUMMONERS.add(BLOCKS.register("clinic_summoner_" + i,
                    () -> new ClinicSummonerBlock(tier, BlockBehaviour.Properties.of().strength(2.5F).sound(SoundType.METAL))));
        }

        for (FurnitureType type : FurnitureType.values()) {
            FURNITURE.put(type, BLOCKS.register(type.id(),
                    () -> type.isTall()
                            ? new TallFurnitureBlock(type, BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().sound(type.sound()))
                            : new FurnitureBlock(type, BlockBehaviour.Properties.of().strength(1.5F).noOcclusion().sound(type.sound()))));
        }
    }
}
