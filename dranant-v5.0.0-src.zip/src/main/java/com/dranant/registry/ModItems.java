package com.dranant.registry;

import com.dranant.DoctorAnantMod;
import com.dranant.block.FurnitureType;
import com.dranant.entity.SupercarVariant;
import com.dranant.item.*;
import net.minecraft.world.item.*;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.ArrayList;
import java.util.List;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(DoctorAnantMod.MODID);

    // Medicines (Tiers 1-10)
    public static final DeferredItem<MedicineItem> FEVER_SYRUP = ITEMS.register("fever_syrup", () -> new MedicineItem(1, 1));
    public static final DeferredItem<MedicineItem> SPEED_VITAMIN_DROPS = ITEMS.register("speed_vitamin_drops", () -> new MedicineItem(2, 2));
    public static final DeferredItem<MedicineItem> IRON_BONE_CAPSULE = ITEMS.register("iron_bone_capsule", () -> new MedicineItem(3, 4));
    public static final DeferredItem<MedicineItem> XRAY_VISION_TONIC = ITEMS.register("xray_vision_tonic", () -> new MedicineItem(4, 8));
    public static final DeferredItem<MedicineItem> VITALITY_HEART_INJECTION = ITEMS.register("vitality_heart_injection", () -> new MedicineItem(5, 16));
    public static final DeferredItem<MedicineItem> REGENERATION_SERUM = ITEMS.register("regeneration_serum", () -> new MedicineItem(6, 24));
    public static final DeferredItem<MedicineItem> TITAN_STRENGTH_SERUM = ITEMS.register("titan_strength_serum", () -> new MedicineItem(7, 32));
    public static final DeferredItem<MedicineItem> FIRE_SHIELD_SERUM = ITEMS.register("fire_shield_serum", () -> new MedicineItem(8, 48));
    public static final DeferredItem<MedicineItem> OMEGA_SUPER_SERUM = ITEMS.register("omega_super_serum", () -> new MedicineItem(9, 64));
    public static final DeferredItem<MedicineItem> IMMORTALITY_ELIXIR = ITEMS.register("immortality_elixir", () -> new MedicineItem(10, 128));

    public static final List<DeferredItem<MedicineItem>> MEDICINES = List.of(
            FEVER_SYRUP, SPEED_VITAMIN_DROPS, IRON_BONE_CAPSULE, XRAY_VISION_TONIC,
            VITALITY_HEART_INJECTION, REGENERATION_SERUM, TITAN_STRENGTH_SERUM,
            FIRE_SHIELD_SERUM, OMEGA_SUPER_SERUM, IMMORTALITY_ELIXIR
    );

    // Special items
    public static final DeferredItem<ExpiredExperimentalSerumItem> EXPIRED_EXPERIMENTAL_SERUM = ITEMS.register("expired_experimental_serum", ExpiredExperimentalSerumItem::new);
    public static final DeferredItem<TitaniumHandcuffsItem> TITANIUM_HANDCUFFS = ITEMS.register("titanium_handcuffs", TitaniumHandcuffsItem::new);
    public static final DeferredItem<UniversalCureSyringeItem> UNIVERSAL_CURE_SYRINGE = ITEMS.register("universal_cure_syringe", UniversalCureSyringeItem::new);
    public static final DeferredItem<ArmorItem> DR_ANANT_COAT = ITEMS.register("dr_anant_coat",
            () -> new DrAnantCoatItem(ModArmorMaterials.DR_ANANT, ArmorItem.Type.CHESTPLATE, new Item.Properties().stacksTo(1)));

    // Clinic & City Block Items
    public static final List<DeferredItem<Item>> CLINIC_SUMMONERS = new ArrayList<>();
    public static final DeferredItem<BlockItem> CENTRAL_SHOP_SPAWNER = ITEMS.registerSimpleBlockItem("central_shop_spawner", ModBlocks.CENTRAL_SHOP_SPAWNER);
    public static final DeferredItem<BlockItem> ITEM_DISPLAY_PEDESTAL = ITEMS.registerSimpleBlockItem("item_display_pedestal", ModBlocks.ITEM_DISPLAY_PEDESTAL);
    public static final DeferredItem<BlockItem> EXAMINATION_BED = ITEMS.registerSimpleBlockItem("examination_bed", ModBlocks.EXAMINATION_BED);
    public static final DeferredItem<BlockItem> DIAMOND_CASH_REGISTER = ITEMS.registerSimpleBlockItem("diamond_cash_register", ModBlocks.DIAMOND_CASH_REGISTER);
    public static final DeferredItem<BlockItem> POSTER_LANDSCAPE = ITEMS.registerSimpleBlockItem("poster_landscape", ModBlocks.POSTER_LANDSCAPE);
    public static final DeferredItem<BlockItem> POSTER_SQUARE = ITEMS.registerSimpleBlockItem("poster_square", ModBlocks.POSTER_SQUARE);
    public static final DeferredItem<BlockItem> POSTER_BILLBOARD = ITEMS.registerSimpleBlockItem("poster_billboard", ModBlocks.POSTER_BILLBOARD);
    public static final DeferredItem<BlockItem> STRETCHER = ITEMS.registerSimpleBlockItem("stretcher", ModBlocks.STRETCHER);
    public static final DeferredItem<BlockItem> CITY_FOUNDER = ITEMS.registerSimpleBlockItem("city_founder", ModBlocks.CITY_FOUNDER);

    // V5 New Block Item
    public static final DeferredItem<BlockItem> FACTORY_BUSTER_TNT = ITEMS.registerSimpleBlockItem("factory_buster_tnt", ModBlocks.FACTORY_BUSTER_TNT);

    // Vehicles & Weapons
    public static final DeferredItem<BikeItem> DR_ANANT_BIKE = ITEMS.register("dr_anant_bike", BikeItem::new);
    public static final DeferredItem<SidekickWhistleItem> SIDEKICK_WHISTLE = ITEMS.register("sidekick_whistle", SidekickWhistleItem::new);
    public static final DeferredItem<Item> SIDEKICK_BLASTER = ITEMS.register("sidekick_blaster", () -> new Item(new Item.Properties().stacksTo(1)));
    public static final DeferredItem<PlasmaRifleItem> PLASMA_RIFLE = ITEMS.register("plasma_rifle", PlasmaRifleItem::new);
    public static final DeferredItem<SurgeonKatanaItem> SURGEON_KATANA = ITEMS.register("surgeon_katana", SurgeonKatanaItem::new);
    public static final DeferredItem<DefibrillatorHammerItem> DEFIBRILLATOR_HAMMER = ITEMS.register("defibrillator_hammer", DefibrillatorHammerItem::new);

    public static final DeferredItem<SupercarItem> SUPERCAR_VELOCE = ITEMS.register("supercar_veloce", () -> new SupercarItem(SupercarVariant.VELOCE));
    public static final DeferredItem<SupercarItem> SUPERCAR_GT = ITEMS.register("supercar_gt", () -> new SupercarItem(SupercarVariant.GT));
    public static final DeferredItem<SupercarItem> SUPERCAR_PHANTOM = ITEMS.register("supercar_phantom", () -> new SupercarItem(SupercarVariant.PHANTOM));

    // V5 New Weapons
    public static final DeferredItem<HeavyMachineGunItem> HEAVY_MACHINE_GUN = ITEMS.register("heavy_machine_gun", HeavyMachineGunItem::new);
    public static final DeferredItem<SciFiM254RifleItem> SCIFI_M254_RIFLE = ITEMS.register("scifi_m254_rifle", SciFiM254RifleItem::new);

    // Spawn Eggs
    public static final DeferredItem<Item> MUTANT_BLOOD_BEAST_SPAWN_EGG = ITEMS.register("mutant_blood_beast_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.MUTANT_BLOOD_BEAST, 0x880000, 0x000000, new Item.Properties()));
    public static final DeferredItem<Item> ASSISTANT_PHARMACIST_SPAWN_EGG = ITEMS.register("assistant_pharmacist_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ASSISTANT_PHARMACIST, 0x00AA00, 0xFFFFFF, new Item.Properties()));
    public static final DeferredItem<Item> SHOPKEEPER_SPAWN_EGG = ITEMS.register("shopkeeper_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SHOPKEEPER, 0x555555, 0xDDDDDD, new Item.Properties()));
    public static final DeferredItem<Item> PATIENT_VILLAGER_SPAWN_EGG = ITEMS.register("patient_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.PATIENT_VILLAGER, 0xBD8B72, 0x4B3B2F, new Item.Properties()));
    public static final DeferredItem<Item> SIDEKICK_SPAWN_EGG = ITEMS.register("sidekick_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.SIDEKICK, 0x222222, 0x00FFCC, new Item.Properties()));
    public static final DeferredItem<Item> ASSISTANT_SCIENTIST_SPAWN_EGG = ITEMS.register("assistant_scientist_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.ASSISTANT_SCIENTIST, 0x0088CC, 0xFFFFFF, new Item.Properties()));

    // V5 New Spawn Eggs
    public static final DeferredItem<Item> FACTORY_GUARD_SPAWN_EGG = ITEMS.register("factory_guard_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.FACTORY_GUARD, 0x333333, 0xFF2200, new Item.Properties()));
    public static final DeferredItem<Item> DRIVER_VILLAGER_SPAWN_EGG = ITEMS.register("driver_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.DRIVER_VILLAGER, 0x3A5FCD, 0xFFD700, new Item.Properties()));
    public static final DeferredItem<Item> CUSTOMER_VILLAGER_SPAWN_EGG = ITEMS.register("customer_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CUSTOMER_VILLAGER, 0x00C957, 0xEEEEEE, new Item.Properties()));
    public static final DeferredItem<Item> CONSULTATION_VILLAGER_SPAWN_EGG = ITEMS.register("consultation_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.CONSULTATION_VILLAGER, 0xFFA500, 0x551A8B, new Item.Properties()));
    public static final DeferredItem<Item> HOSPITAL_BED_VILLAGER_SPAWN_EGG = ITEMS.register("hospital_bed_villager_spawn_egg",
            () -> new DeferredSpawnEggItem(ModEntities.HOSPITAL_BED_VILLAGER, 0x87CEEB, 0xFFFFFF, new Item.Properties()));

    static {
        for (int i = 1; i <= ModBlocks.CLINIC_TIERS; i++) {
            final int tier = i;
            CLINIC_SUMMONERS.add(ITEMS.register("clinic_summoner_" + i,
                    () -> new ClinicSummonerItem(ModBlocks.CLINIC_SUMMONERS.get(tier - 1).get(), tier)));
        }

        for (FurnitureType type : FurnitureType.values()) {
            ITEMS.registerSimpleBlockItem(type.id(), ModBlocks.FURNITURE.get(type));
        }
    }
}
