package com.dranant.block;

import net.minecraft.core.Direction;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

public enum FurnitureType {
    MODERN_SOFA("modern_sofa", "Modern Sofa", 9, 0, false),
    COFFEE_TABLE("coffee_table", "Coffee Table", 0, 0, false),
    TV_STAND("tv_stand", "TV Stand", 0, 0, false),
    DINING_TABLE("dining_table", "Dining Table", 0, 0, false),
    DINING_CHAIR("dining_chair", "Dining Chair", 9, 0, false),
    KITCHEN_COUNTER("kitchen_counter", "Kitchen Counter", 0, 0, false),
    KITCHEN_SINK("kitchen_sink", "Kitchen Sink", 0, 0, false),
    KITCHEN_STOVE("kitchen_stove", "Kitchen Stove", 0, 10, false),
    FRIDGE("fridge", "Fridge", 0, 0, true),
    FLOOR_LAMP("floor_lamp", "Floor Lamp", 0, 14, true),
    OFFICE_DESK("office_desk", "Office Desk", 0, 0, false),
    MODERN_TOILET("modern_toilet", "Modern Toilet", 9, 0, false),
    BATHROOM_VANITY("bathroom_vanity", "Bathroom Vanity", 0, 0, false);

    private final String id;
    private final String title;
    private final int seatHeight;
    private final int light;
    private final boolean tall;

    FurnitureType(String id, String title, int seatHeight, int light, boolean tall) {
        this.id = id;
        this.title = title;
        this.seatHeight = seatHeight;
        this.light = light;
        this.tall = tall;
    }

    public String id() { return id; }
    public String title() { return title; }
    public int seatHeight() { return seatHeight; }
    public int light() { return light; }
    public boolean tall() { return tall; }

    public VoxelShape shape(Direction dir, boolean upper) {
        if (tall && upper) {
            return Shapes.box(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
        }
        return Shapes.box(0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
    }
}
