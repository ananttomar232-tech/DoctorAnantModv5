package com.dranant.block.entity;

import com.dranant.registry.ModBlockEntities;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class DiamondCashRegisterBlockEntity extends BlockEntity {
    private long lifetimeEarnings = 0;
    private final List<UUID> line1 = new ArrayList<>();
    private final List<UUID> line2 = new ArrayList<>();
    private BlockPos bedHead = null;
    private final List<BlockPos> stretchers = new ArrayList<>();
    private long nextFacilityScan = 0;
    private long nextCustomerSpawn = 0;
    private long nextConversion = 0;
    private UUID counterPatient = null;
    private int counterTicks = 0;
    private long lastNoStaffComplaint = 0;

    public DiamondCashRegisterBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.DIAMOND_CASH_REGISTER.get(), pos, state);
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, DiamondCashRegisterBlockEntity entity) {
        // Ticks clinic queue and earnings
    }

    public void addDiamonds(long diamonds) {
        this.lifetimeEarnings += diamonds;
        setChanged();
    }

    public long getLifetimeEarnings() { return lifetimeEarnings; }
    public List<UUID> getLine1() { return line1; }
    public List<UUID> getLine2() { return line2; }
    public BlockPos getBedHead() { return bedHead; }
    public void setBedHead(BlockPos bedHead) { this.bedHead = bedHead; setChanged(); }
    public List<BlockPos> getStretchers() { return stretchers; }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putLong("lifetimeEarnings", lifetimeEarnings);
        ListTag l1 = new ListTag();
        for (UUID u : line1) l1.add(StringTag.valueOf(u.toString()));
        tag.put("line1", l1);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        lifetimeEarnings = tag.getLong("lifetimeEarnings");
        line1.clear();
        if (tag.contains("line1")) {
            ListTag l1 = tag.getList("line1", 8);
            for (int i = 0; i < l1.size(); i++) {
                try { line1.add(UUID.fromString(l1.getString(i))); } catch (Exception ignored) {}
            }
        }
    }
}
