package com.dranant.block.entity;

import com.dranant.registry.ModBlockEntities;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

public class ExaminationBedBlockEntity extends BlockEntity {
    private UUID patient = null;

    public ExaminationBedBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.EXAMINATION_BED.get(), pos, state);
    }

    public UUID getPatient() { return patient; }
    public void setPatient(UUID patient) { this.patient = patient; setChanged(); }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        if (patient != null) tag.putUUID("patient", patient);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        if (tag.hasUUID("patient")) patient = tag.getUUID("patient");
    }
}
