package com.dranant.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;

public class PosterSquareBlock extends PosterBlock {
    public PosterSquareBlock(Properties properties) {
        super(properties, 1, 1);
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() { return null; }
}
