package com.dranant.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;

public class PosterBillboardBlock extends PosterBlock {
    public PosterBillboardBlock(Properties properties) {
        super(properties, 3, 2);
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() { return null; }
}
