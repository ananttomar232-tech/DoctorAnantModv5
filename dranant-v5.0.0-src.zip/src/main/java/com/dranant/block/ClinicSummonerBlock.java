package com.dranant.block;

import com.dranant.clinic.ClinicBuilder;
import com.dranant.clinic.ClinicTiers;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

public class ClinicSummonerBlock extends Block {
    private final int tier;

    public ClinicSummonerBlock(Properties properties, int tier) {
        super(properties);
        this.tier = tier;
    }

    public int getTier() { return tier; }
    public String getClinicName() { return ClinicTiers.name(tier); }

    @Override
    protected MapCodec<? extends Block> codec() { return null; }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (level instanceof ServerLevel sl) {
            ClinicBuilder.summonAt(sl, player, tier, pos);
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level instanceof ServerLevel sl && placer instanceof Player player) {
            ClinicBuilder.summonAt(sl, player, tier, pos);
        }
    }
}
