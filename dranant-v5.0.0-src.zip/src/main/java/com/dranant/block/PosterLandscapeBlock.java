package com.dranant.block;

import com.mojang.serialization.MapCodec;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;

public class PosterLandscapeBlock extends PosterBlock {
    public PosterLandscapeBlock(Properties properties) {
        super(properties, 2, 1);
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() { return null; }
}
