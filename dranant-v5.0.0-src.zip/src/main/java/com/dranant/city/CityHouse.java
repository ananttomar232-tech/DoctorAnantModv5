package com.dranant.city;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

public class CityHouse {
    public static void build(ServerLevel level, BlockPos origin, int width, int depth) {
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                level.setBlock(origin.offset(x, 0, z), Blocks.STONE_BRICKS.defaultBlockState(), 3);
                for (int y = 1; y <= 4; y++) {
                    if (x == 0 || x == width - 1 || z == 0 || z == depth - 1) {
                        level.setBlock(origin.offset(x, y, z), Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
                    } else {
                        level.setBlock(origin.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                    }
                }
                level.setBlock(origin.offset(x, 5, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
            }
        }
        level.setBlock(origin.offset(width / 2, 1, 0), Blocks.AIR.defaultBlockState(), 3);
        level.setBlock(origin.offset(width / 2, 2, 0), Blocks.AIR.defaultBlockState(), 3);
    }
}
