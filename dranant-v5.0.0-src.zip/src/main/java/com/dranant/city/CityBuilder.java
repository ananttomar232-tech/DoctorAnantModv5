package com.dranant.city;

import com.dranant.entity.CityTrafficVehicleEntity;
import com.dranant.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class CityBuilder {
    public static boolean found(ServerLevel level, Player player) {
        BlockPos center = player.blockPosition();

        // 1. Build Widened City Roads (14 blocks wide)
        int r = CityLayout.CITY_RADIUS;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int x = -r; x <= r; x++) {
            for (int z = -r; z <= r; z++) {
                if (CityLayout.isRoad(x, z)) {
                    p.set(center.getX() + x, center.getY() - 1, center.getZ() + z);
                    
                    // Road lanes:
                    // Center divider (white concrete)
                    if (x == 0 || z == 0) {
                        level.setBlock(p, Blocks.WHITE_CONCRETE.defaultBlockState(), 3);
                    } 
                    // Bike lane outer edge (cyan/light blue concrete)
                    else if (Math.abs(x) == 6 || Math.abs(z) == 6) {
                        level.setBlock(p, Blocks.CYAN_CONCRETE.defaultBlockState(), 3);
                    }
                    // Sidewalk curbs (smooth stone slab)
                    else if (Math.abs(x) == 7 || Math.abs(z) == 7) {
                        level.setBlock(p.above(), Blocks.SMOOTH_STONE_SLAB.defaultBlockState(), 3);
                        level.setBlock(p, Blocks.STONE_BRICKS.defaultBlockState(), 3);
                    }
                    // Driving lanes (smooth black concrete)
                    else {
                        level.setBlock(p, Blocks.BLACK_CONCRETE.defaultBlockState(), 3);
                    }

                    // Clear space above road
                    for (int h = 0; h < 6; h++) {
                        BlockPos airPos = p.above(1 + h);
                        if (!level.isEmptyBlock(airPos)) {
                            level.setBlock(airPos, Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            }
        }

        // 2. Build Showroom
        BlockPos showroomPos = center.offset(25, 0, 25);
        CityShowroom.buildShowroom(level, showroomPos);

        // 3. Build Mutant Blood Beast Factory in the far outskirts (Z + 220)
        BlockPos factoryPos = center.offset(-120, 0, 220);
        MutantFactoryBuilder.buildFactory(level, factoryPos);

        // 4. Spawn AI City Traffic Vehicles with Driver Villagers
        for (int i = 0; i < 6; i++) {
            CityTrafficVehicleEntity car = new CityTrafficVehicleEntity(ModEntities.CITY_TRAFFIC_VEHICLE.get(), level);
            double sx = center.getX() + (i % 2 == 0 ? 3.0 : -3.0);
            double sz = center.getZ() + (i * 30 - 90);
            car.setPos(sx, center.getY(), sz);
            car.setYRot(i % 2 == 0 ? 0.0F : 180.0F);
            level.addFreshEntity(car);
        }

        player.displayClientMessage(net.minecraft.network.chat.Component.literal("§a[City Founder] Dr. Anant City successfully established!
- Roads Widened (14 blocks)
- AI Traffic Dispatched
- Supercar Showroom Built
- Mutant Factory Detected in Outskirts!"), false);
        return true;
    }
}
