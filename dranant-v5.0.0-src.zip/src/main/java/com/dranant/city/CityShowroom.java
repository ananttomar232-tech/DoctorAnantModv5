package com.dranant.city;

import com.dranant.entity.SupercarEntity;
import com.dranant.entity.SupercarVariant;
import com.dranant.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Display;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Blocks;

public class CityShowroom {
    public static final int[][] PODIUMS = {
        { -12, 1, 0 },
        { 0, 1, 0 },
        { 12, 1, 0 }
    };

    public static final SupercarVariant[] CARS = {
        SupercarVariant.GT,
        SupercarVariant.VELOCE,
        SupercarVariant.PHANTOM
    };

    public static void buildShowroom(ServerLevel level, BlockPos origin) {
        // Build floor, glass walls and lighting
        int w = 36;
        int d = 24;
        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        for (int x = -w/2; x <= w/2; x++) {
            for (int z = -d/2; z <= d/2; z++) {
                p.set(origin.getX() + x, origin.getY(), origin.getZ() + z);
                level.setBlock(p, Blocks.SMOOTH_QUARTZ.defaultBlockState(), 3);

                // Perimeter glass
                if (Math.abs(x) == w/2 || Math.abs(z) == d/2) {
                    for (int y = 1; y <= 6; y++) {
                        p.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                        level.setBlock(p, Blocks.GLASS.defaultBlockState(), 3);
                    }
                }
            }
        }

        // Spawn cars on display podiums
        for (int i = 0; i < 3; i++) {
            SupercarVariant v = CARS[i];
            int px = origin.getX() + PODIUMS[i][0];
            int py = origin.getY() + 1;
            int pz = origin.getZ() + PODIUMS[i][2];

            // Rotating showroom car
            SupercarEntity car = new SupercarEntity(ModEntities.SUPERCAR.get(), level);
            car.setVariant(v);
            car.setPos(px + 0.5, py, pz + 0.5);
            car.setShowroom(true, true); // Turntable rotating
            car.setLocked(true); // Locked until bought
            level.addFreshEntity(car);

            // Price Hologram Display
            Display.TextDisplay text = new Display.TextDisplay(EntityType.TEXT_DISPLAY, level);
            text.setPos(px + 0.5, py + 2.2, pz + 0.5);
            text.setText(Component.literal("§6§l" + v.displayName() + "
§e§lPRICE: " + v.diamondPrice() + " DIAMONDS
§7[Hold Diamonds & Right-Click Car to Buy]"));
            text.setBillboardConstraints(Display.BillboardConstraints.CENTER);
            level.addFreshEntity(text);
        }
    }
}
