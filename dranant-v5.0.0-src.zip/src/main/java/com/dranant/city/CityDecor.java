package com.dranant.city;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class CityDecor {
    public static void lamp(ServerLevel level, BlockPos pos) {
        level.setBlock(pos, Blocks.COBBLESTONE_WALL.defaultBlockState(), 3);
        level.setBlock(pos.above(), Blocks.COBBLESTONE_WALL.defaultBlockState(), 3);
        level.setBlock(pos.above(2), Blocks.LANTERN.defaultBlockState(), 3);
    }

    public static void bench(ServerLevel level, BlockPos pos, Direction facing) {
        level.setBlock(pos, Blocks.OAK_STAIRS.defaultBlockState(), 3);
    }

    public static void tree(ServerLevel level, BlockPos pos) {
        for (int y = 0; y < 4; y++) {
            level.setBlock(pos.above(y), Blocks.OAK_LOG.defaultBlockState(), 3);
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                for (int dy = 2; dy <= 4; dy++) {
                    if (Math.abs(dx) + Math.abs(dz) <= 3) {
                        BlockPos lp = pos.offset(dx, dy, dz);
                        if (level.isEmptyBlock(lp)) {
                            level.setBlock(lp, Blocks.OAK_LEAVES.defaultBlockState(), 3);
                        }
                    }
                }
            }
        }
    }
}
