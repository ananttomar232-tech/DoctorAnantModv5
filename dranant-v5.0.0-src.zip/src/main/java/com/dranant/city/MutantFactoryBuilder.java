package com.dranant.city;

import com.dranant.entity.FactoryGuardEntity;
import com.dranant.entity.MutantBloodBeastEntity;
import com.dranant.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class MutantFactoryBuilder {
    public static void buildFactory(ServerLevel level, BlockPos origin) {
        int width = 36;
        int depth = 36;
        int height = 14;

        BlockPos.MutableBlockPos p = new BlockPos.MutableBlockPos();

        // 1. Foundation & Walls (Reinforced Black & Gray Concrete, Iron Bars)
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                for (int y = -2; y <= height; y++) {
                    p.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (y <= 0) {
                        level.setBlock(p, Blocks.POLISHED_BLACKSTONE.defaultBlockState(), 3);
                    } else if (y == height) {
                        level.setBlock(p, Blocks.GRAY_CONCRETE.defaultBlockState(), 3);
                    } else if (x == 0 || x == width - 1 || z == 0 || z == depth - 1) {
                        if (y % 4 == 0) {
                            level.setBlock(p, Blocks.RED_CONCRETE.defaultBlockState(), 3);
                        } else if (y == 5 || y == 6) {
                            level.setBlock(p, Blocks.IRON_BARS.defaultBlockState(), 3);
                        } else {
                            level.setBlock(p, Blocks.BLACK_CONCRETE.defaultBlockState(), 3);
                        }
                    } else {
                        level.setBlock(p, Blocks.AIR.defaultBlockState(), 3);
                    }
                }
            }
        }

        // 2. High-Tech Mutant Incubation Tanks in Center
        int cx = origin.getX() + width / 2;
        int cz = origin.getZ() + depth / 2;
        int cy = origin.getY() + 1;

        for (int i = -1; i <= 1; i += 2) {
            for (int j = -1; j <= 1; j += 2) {
                BlockPos vatBase = new BlockPos(cx + i * 8, cy, cz + j * 8);
                // Glass cylinder vat
                for (int vy = 0; vy < 5; vy++) {
                    level.setBlock(vatBase.above(vy), Blocks.RED_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(vatBase.above(vy).north(), Blocks.RED_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(vatBase.above(vy).south(), Blocks.RED_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(vatBase.above(vy).east(), Blocks.RED_STAINED_GLASS.defaultBlockState(), 3);
                    level.setBlock(vatBase.above(vy).west(), Blocks.RED_STAINED_GLASS.defaultBlockState(), 3);
                }
                level.setBlock(vatBase.above(5), Blocks.REDSTONE_LAMP.defaultBlockState(), 3);
                level.setBlock(vatBase.above(6), Blocks.REDSTONE_BLOCK.defaultBlockState(), 3);

                // Spawn a Mutant Blood Beast inside/near vat!
                MutantBloodBeastEntity beast = new MutantBloodBeastEntity(ModEntities.MUTANT_BLOOD_BEAST.get(), level);
                beast.setPos(vatBase.getX() + 0.5, cy + 1, vatBase.getZ() + 0.5);
                level.addFreshEntity(beast);
            }
        }

        // 3. Spawn Factory Guards (Mercenaries protecting the facility)
        for (int g = 0; g < 6; g++) {
            FactoryGuardEntity guard = new FactoryGuardEntity(ModEntities.FACTORY_GUARD.get(), level);
            double gx = origin.getX() + 4 + (g * 5);
            double gz = origin.getZ() + (g % 2 == 0 ? 4 : depth - 4);
            guard.setPos(gx, cy, gz);
            level.addFreshEntity(guard);
        }

        // Outside perimeter guards
        for (int og = 0; og < 4; og++) {
            FactoryGuardEntity outerGuard = new FactoryGuardEntity(ModEntities.FACTORY_GUARD.get(), level);
            outerGuard.setPos(origin.getX() - 3 + og * 12, cy, origin.getZ() - 4);
            level.addFreshEntity(outerGuard);
        }
    }
}
