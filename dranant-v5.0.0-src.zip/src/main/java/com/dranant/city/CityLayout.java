package com.dranant.city;

import net.minecraft.core.BlockPos;

public class CityLayout {
    public static final int ROAD_WIDTH = 14; // WIDENED: 2 supercars + 2 superbikes side-by-side!
    public static final int CITY_RADIUS = 180;

    public record Plot(int tier, int x, int z, int width, int depth) {}

    public static boolean isRoad(int x, int z) {
        // Main avenue cross roads + ring road
        int ax = Math.abs(x);
        int az = Math.abs(z);
        if (ax <= ROAD_WIDTH / 2 || az <= ROAD_WIDTH / 2) return true;
        if (Math.abs(ax - 100) <= ROAD_WIDTH / 2 || Math.abs(az - 100) <= ROAD_WIDTH / 2) return true;
        return false;
    }
}
