package com.dranant.city;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;

public class CityBuildings {
    public static void cottage(ServerLevel level, BlockPos origin) {
        CityHouse.build(level, origin, 9, 11);
    }

    public static void villa(ServerLevel level, BlockPos origin) {
        CityHouse.build(level, origin, 13, 15);
    }

    public static void apartment(ServerLevel level, BlockPos origin) {
        CityHouse.build(level, origin, 15, 17);
    }
}
