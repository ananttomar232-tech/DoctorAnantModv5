package com.dranant.city;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class StatueData {
    public static final Map<Character, BlockState> PALETTE = new HashMap<>();
    public static final String[] ROWS = {
        "  GGG  ",
        " GGGGG ",
        "  GGG  ",
        "  BBB  ",
        " BBBBB ",
        "  BBB  ",
        "  L L  ",
        "  L L  "
    };

    static {
        PALETTE.put('G', Blocks.GOLD_BLOCK.defaultBlockState());
        PALETTE.put('B', Blocks.BLUE_CONCRETE.defaultBlockState());
        PALETTE.put('L', Blocks.NETHERITE_BLOCK.defaultBlockState());
    }
}
