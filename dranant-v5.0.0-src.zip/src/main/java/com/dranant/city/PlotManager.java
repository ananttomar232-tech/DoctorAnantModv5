package com.dranant.city;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;

public class PlotManager {
    public static void info(ServerLevel level, BlockPos pos, Player player) {
        // Plot info display
    }
}
