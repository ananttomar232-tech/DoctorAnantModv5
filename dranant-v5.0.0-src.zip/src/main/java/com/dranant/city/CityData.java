package com.dranant.city;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.saveddata.SavedData;

public class CityData extends SavedData {
    public static final String NAME = "dranant_city";

    private boolean hasCity = false;
    private boolean cityComplete = false;
    private BlockPos cityOrigin = BlockPos.ZERO;
    private Rotation cityRotation = Rotation.NONE;
    private int buildingCount = 0;

    public static CityData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(
            new SavedData.Factory<>(CityData::new, CityData::load),
            NAME
        );
    }

    public static CityData load(CompoundTag tag, HolderLookup.Provider provider) {
        CityData data = new CityData();
        data.hasCity = tag.getBoolean("hasCity");
        data.cityComplete = tag.getBoolean("cityComplete");
        data.cityOrigin = new BlockPos(tag.getInt("ox"), tag.getInt("oy"), tag.getInt("oz"));
        data.buildingCount = tag.getInt("buildingCount");
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag, HolderLookup.Provider provider) {
        tag.putBoolean("hasCity", hasCity);
        tag.putBoolean("cityComplete", cityComplete);
        tag.putInt("ox", cityOrigin.getX());
        tag.putInt("oy", cityOrigin.getY());
        tag.putInt("oz", cityOrigin.getZ());
        tag.putInt("buildingCount", buildingCount);
        return tag;
    }

    public boolean hasCity() { return hasCity; }
    public boolean isCityComplete() { return cityComplete; }
    public BlockPos getCityOrigin() { return cityOrigin; }
    public void setCity(BlockPos origin, Rotation rot) {
        this.hasCity = true;
        this.cityOrigin = origin;
        this.cityRotation = rot;
        setDirty();
    }
    public void setCityComplete(boolean complete) {
        this.cityComplete = complete;
        setDirty();
    }
}
