package com.dranant.dialogue;

import net.minecraft.util.RandomSource;

public class Lines {
    public static final String[] MILD_PROBLEMS = {
        "Mujhe 3 din se bukhaar hai!",
        "Sir mein bahut dard hai bhaiya...",
        "Khansi ruk hi nahi rahi! *khoo khoo*",
        "Creeper ne daraya, BP high ho gaya!",
        "Pet kharab hai, kal 64 golgappe khaye!",
        "Phantom ki wajah se neend nahi aati!",
        "Mining karte karte haath mein moch aa gayi.",
        "Zombie ne thoda sa kaat liya... bas thoda sa.",
        "Aankhon mein jalan hai, lava dekh liya tha.",
        "Gala kharab hai, gaana nahi ga pa raha!",
        "Bees ne kaat liya, honey churane gaya tha.",
        "Daant mein dard hai, bread bahut sakht thi!"
    };

    public static final String[] SEVERE_PROBLEMS = {
        "Skeleton ka teer lag gaya! Jaldi karo!",
        "Haddi toot gayi, chal nahi pa raha!",
        "Lava mein gir gaya tha... sab jal gaya!",
        "Wither ne attack kiya... saans nahi aa rahi!",
        "Bahut chakkar aa rahe hain doctor saab...",
        "Pillager ne maara, bahut khoon beh raha hai!",
        "Warden se mil ke aaya hoon... kuch sunai nahi deta!",
        "Pahad se gir gaya, poora body dard kar raha hai!"
    };

    public static final String[] WAITING = {
        "Kitni der lagegi bhai?",
        "Line aage badhao!",
        "Aah... dard ho raha hai...",
        "Mere aage wala bahut time le raha hai!",
        "Suna hai Dr. Anant ki dawai jaadu hai!",
        "Mujhe pehle jaane do, emergency hai!",
        "Yahan WiFi hai kya?",
        "Mummy ne bola tha Dr. Anant ke paas hi jaana."
    };

    public static final String[] HAGGLE = {
        "Bhaiya thoda discount do na!",
        "Itna mehenga? Gaon mein 1 diamond mein milta hai!",
        "Main roz aata hoon, regular customer hoon!",
        "Dr. Anant ne bola tha free milegi!",
        "Do le lunga, ek free do!",
        "Mere paas sirf emeralds hain, chalega?"
    };

    public static final String[] PHARMACIST_REPLY = {
        "Rate fixed hai bhai, Dr. Anant ki dawai hai!",
        "Chalo, aapke liye special price!",
        "Peeche line lambi hai, jaldi bolo!",
        "Emeralds nahi, sirf diamonds chalte hain!",
        "Isse sasta poore server mein nahi milega!",
        "Theek hai, thoda kam kar deta hoon."
    };

    public static final String[] PHARMACIST_ADVICE = {
        "Ye lo, din mein do baar khana ke baad!",
        "Ye dawai lo, 2 din mein theek ho jaoge!",
        "Thanda paani mat peena, theek?",
        "Aaram karo aur phantom se door raho!"
    };

    public static final String[] DEAL = {
        "Theek hai, ye lo diamonds!",
        "Chalo, le lo. Dhanyavaad!",
        "Okay okay, deal pakki!",
        "Dr. Anant zindabad! Ye lo payment."
    };

    public static final String[] CURED_MILD = {
        "Ab bilkul theek lag raha hai!",
        "Wah! Dawai ne turant kaam kiya!",
        "Main sabko bataunga is clinic ke baare mein!"
    };

    public static final String[] SCIENTIST_LINES = {
        "Ghabrao mat, Dr. Anant ka formula hai!",
        "Bas ek chhota sa injection...",
        "Experimental treatment shuru!",
        "Lete raho, hilna mat!"
    };

    public static final String[] SEVERE_CURED = {
        "Wah! Main bilkul theek ho gaya!",
        "Dr. Anant zindabad! Ye lo 64 diamonds!",
        "Chamatkar! Main fir se chal sakta hoon!"
    };

    public static final String[] TALKING_PATIENT = {
        "Doctor saab, main subah se wait kar raha hoon!",
        "Aapki clinic ki rating 5 star hai na?",
        "Pata hai, pichhle saal mujhe zombie ne gher liya tha...",
        "Aapke paas wo immortality serum bacha hai?",
        "Main gaon ka sarpanch hoon, mujhe VIP treatment chahiye!"
    };

    public static final String[] BED_PATIENT = {
        "Doctor saab kab aayenge?",
        "Ye bed bahut comfortable hai...",
        "Mujhe injection mat lagana please!",
        "Thoda aaram karne do bhai...",
        "Dr. Anant ki dawai asar kar rahi hai zzz..."
    };

    public static String pick(String[] pool, RandomSource rand) {
        if (pool == null || pool.length == 0) return "";
        return pool[rand.nextInt(pool.length)];
    }

    public static String pick(String[] pool, RandomSource rand, String playerName) {
        String s = pick(pool, rand);
        return s.replace("{p}", playerName != null ? playerName : "Doctor");
    }
}
