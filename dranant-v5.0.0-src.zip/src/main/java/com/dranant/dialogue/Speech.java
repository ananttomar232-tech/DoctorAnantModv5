package com.dranant.dialogue;

import com.dranant.network.SpeechPayload;
import net.minecraft.world.entity.Entity;
import net.neoforged.neoforge.network.PacketDistributor;

public class Speech {
    public static final int STYLE_PATIENT = 0;
    public static final int STYLE_STAFF = 1;
    public static final int STYLE_RUDE = 2;
    public static final int STYLE_FRIENDLY = 3;
    public static final int STYLE_BOSS = 4;
    public static final int STYLE_HAPPY = 5;

    public static void say(Entity entity, String text, int style) {
        int duration = Math.min(140, Math.max(50, 30 + text.length() * 2));
        say(entity, text, style, duration);
    }

    public static void say(Entity entity, String text, int style, int duration) {
        if (entity.level().isClientSide()) return;
        PacketDistributor.sendToPlayersTrackingEntity(entity, new SpeechPayload(entity.getId(), text, duration, style));
    }
}
