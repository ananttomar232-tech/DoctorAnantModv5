package com.dranant.client.renderer;

import com.dranant.client.model.MutantBloodBeastModel;
import com.dranant.entity.MutantBloodBeastEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class MutantBloodBeastRenderer extends MobRenderer<MutantBloodBeastEntity, MutantBloodBeastModel> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("dranant", "textures/entity/mutant_blood_beast.png");

    public MutantBloodBeastRenderer(EntityRendererProvider.Context context) {
        super(context, new MutantBloodBeastModel(context.bakeLayer(MutantBloodBeastModel.LAYER)), 1.2f);
    }

    @Override
    protected void scale(MutantBloodBeastEntity livingEntity, PoseStack poseStack, float partialTickTime) {
        poseStack.scale(1.8f, 1.8f, 1.8f);
    }

    @Override
    public ResourceLocation getTextureLocation(MutantBloodBeastEntity entity) {
        return TEXTURE;
    }
}
