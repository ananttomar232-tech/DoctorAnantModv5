package com.dranant.client.renderer;

import com.dranant.entity.SidekickEntity;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.resources.ResourceLocation;

public class SidekickRenderer extends LivingEntityRenderer<SidekickEntity, PlayerModel<SidekickEntity>> {
    private static final ResourceLocation TEXTURE = ResourceLocation.fromNamespaceAndPath("dranant", "textures/entity/sidekick.png");

    public SidekickRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
    }

    @Override
    public ResourceLocation getTextureLocation(SidekickEntity entity) {
        return TEXTURE;
    }
}
