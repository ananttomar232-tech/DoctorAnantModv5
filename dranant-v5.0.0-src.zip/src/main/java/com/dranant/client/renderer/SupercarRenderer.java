package com.dranant.client.renderer;

import com.dranant.client.model.SupercarModel;
import com.dranant.entity.SupercarEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class SupercarRenderer extends EntityRenderer<SupercarEntity> {
    private final SupercarModel model;

    public SupercarRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new SupercarModel(context.bakeLayer(SupercarModel.LAYER));
        this.shadowRadius = 1.2F;
    }

    @Override
    public void render(SupercarEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0, -1.5, 0.0);

        this.model.setupAnim(entity, 0, 0, entity.tickCount + partialTicks, 0, 0);
        this.model.renderToBuffer(poseStack, buffer.getBuffer(this.model.renderType(getTextureLocation(entity))), packedLight, OverlayTexture.NO_OVERLAY);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(SupercarEntity entity) {
        return entity.getVariant().texture();
    }
}
