package com.dranant.client.renderer;

import com.dranant.block.entity.ItemDisplayPedestalBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class ItemDisplayPedestalRenderer implements BlockEntityRenderer<ItemDisplayPedestalBlockEntity> {
    private final ItemRenderer itemRenderer;

    public ItemDisplayPedestalRenderer(BlockEntityRendererProvider.Context context) {
        this.itemRenderer = context.getItemRenderer();
    }

    @Override
    public void render(ItemDisplayPedestalBlockEntity be, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight, int packedOverlay) {
        ItemStack stack = be.getItem();
        if (stack.isEmpty() || be.getLevel() == null) return;

        poseStack.pushPose();

        float gameTime = be.getLevel().getGameTime() + partialTicks;

        if (be.isHovering()) {
            // 360-degree floating and spinning hovering mode!
            float hoverY = 1.35F + (float) Math.sin(gameTime * 0.08F) * 0.08F;
            poseStack.translate(0.5, hoverY, 0.5);

            float rot = (gameTime * 3.5F) % 360.0F;
            poseStack.mulPose(Axis.YP.rotationDegrees(rot));
            poseStack.mulPose(Axis.XP.rotationDegrees(10.0F * (float) Math.sin(gameTime * 0.05F)));
            poseStack.scale(0.85F, 0.85F, 0.85F);
        } else {
            // Standard pedestal presentation
            poseStack.translate(0.5, 1.05, 0.5);
            poseStack.mulPose(Axis.YP.rotationDegrees((gameTime * 1.5F) % 360.0F));
            poseStack.scale(0.7F, 0.7F, 0.7F);
        }

        this.itemRenderer.renderStatic(stack, ItemDisplayContext.FIXED, packedLight, packedOverlay, poseStack, buffer, be.getLevel(), 0);
        poseStack.popPose();
    }
}
