package com.dranant.client.renderer;

import com.dranant.DoctorAnantMod;
import com.dranant.client.model.BikeModel;
import com.dranant.entity.BikeEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

public class BikeRenderer extends EntityRenderer<BikeEntity> {
    private static final ResourceLocation TEXTURE = DoctorAnantMod.id("textures/entity/dr_anant_bike.png");
    private final BikeModel model;

    public BikeRenderer(EntityRendererProvider.Context context) {
        super(context);
        this.model = new BikeModel(context.bakeLayer(BikeModel.LAYER));
        this.shadowRadius = 0.6F;
    }

    @Override
    public void render(BikeEntity entity, float entityYaw, float partialTicks, PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
        poseStack.scale(-1.0F, -1.0F, 1.0F);
        poseStack.translate(0.0, -1.5, 0.0);

        this.model.setupAnim(entity, 0, 0, entity.tickCount + partialTicks, 0, 0);
        this.model.renderToBuffer(poseStack, buffer.getBuffer(this.model.renderType(TEXTURE)), packedLight, OverlayTexture.NO_OVERLAY);

        poseStack.popPose();
        super.render(entity, entityYaw, partialTicks, poseStack, buffer, packedLight);
    }

    @Override
    public ResourceLocation getTextureLocation(BikeEntity entity) {
        return TEXTURE;
    }
}
