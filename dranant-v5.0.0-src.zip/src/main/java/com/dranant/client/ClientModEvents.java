package com.dranant.client;

import com.dranant.DoctorAnantMod;
import com.dranant.client.model.BikeModel;
import com.dranant.client.model.SupercarModel;
import com.dranant.client.renderer.*;
import com.dranant.registry.ModBlockEntities;
import com.dranant.registry.ModEntities;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.NoopRenderer;
import net.minecraft.client.renderer.entity.VillagerRenderer;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.gui.VanillaGuiLayers;
import net.neoforged.neoforge.common.NeoForge;

@EventBusSubscriber(modid = DoctorAnantMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientModEvents {

    @SubscribeEvent
    public static void registerLayers(EntityRenderersEvent.RegisterLayerDefinitions event) {
        event.registerLayerDefinition(SupercarModel.LAYER, SupercarModel::createLayer);
        event.registerLayerDefinition(BikeModel.LAYER, BikeModel::createLayer);
    }

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.SUPERCAR.get(), SupercarRenderer::new);
        event.registerEntityRenderer(ModEntities.DR_ANANT_BIKE.get(), BikeRenderer::new);
        event.registerEntityRenderer(ModEntities.SEAT.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.FACTORY_BUSTER_TNT.get(), NoopRenderer::new);
        event.registerEntityRenderer(ModEntities.CITY_TRAFFIC_VEHICLE.get(), SupercarRenderer::new);

        // Villager roles
        event.registerEntityRenderer(ModEntities.DRIVER_VILLAGER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.CUSTOMER_VILLAGER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.CONSULTATION_VILLAGER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.HOSPITAL_BED_VILLAGER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.PATIENT_VILLAGER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.SHOPKEEPER.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.ASSISTANT_PHARMACIST.get(), VillagerRenderer::new);
        event.registerEntityRenderer(ModEntities.ASSISTANT_SCIENTIST.get(), VillagerRenderer::new);

        // Factory Guard: Humanoid armed with armor
        event.registerEntityRenderer(ModEntities.FACTORY_GUARD.get(), ctx ->
                new HumanoidMobRenderer<>(ctx, new HumanoidModel<>(ctx.bakeLayer(ModelLayers.PLAYER)), 0.5F) {
                    @Override
                    public ResourceLocation getTextureLocation(com.dranant.entity.FactoryGuardEntity entity) {
                        return DoctorAnantMod.id("textures/entity/ninja_outfit.png");
                    }
                });

        // Pedestal block entity renderer (with 360 degree hovering)
        event.registerBlockEntityRenderer(ModBlockEntities.ITEM_DISPLAY_PEDESTAL.get(), ItemDisplayPedestalRenderer::new);
    }

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        VehicleKeys.register(event);
        NeoForge.EVENT_BUS.addListener(ClientModEvents::onKeyInput);
    }

    public static void onKeyInput(InputEvent.Key event) {
        VehicleKeys.onKeyInput(event);
    }

    @SubscribeEvent
    public static void registerGuiLayers(RegisterGuiLayersEvent event) {
        event.registerAbove(VanillaGuiLayers.HOTBAR, DoctorAnantMod.id("vehicle_hud"), (guiGraphics, partialTicks) -> {
            VehicleHudOverlay.render(guiGraphics, partialTicks.getRealtimeDeltaTicks());
        });
    }
}
