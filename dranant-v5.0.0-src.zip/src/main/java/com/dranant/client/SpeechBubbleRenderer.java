package com.dranant.client;

import com.dranant.network.ClientSpeechData;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLivingEvent;

@EventBusSubscriber(modid = "dranant", value = Dist.CLIENT)
public class SpeechBubbleRenderer {
    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Post<?, ?> event) {
        LivingEntity entity = event.getEntity();
        String speech = ClientSpeechData.getSpeech(entity.getId());
        if (speech == null || speech.isEmpty()) return;

        PoseStack poseStack = event.getPoseStack();
        MultiBufferSource buffer = event.getMultiBufferSource();
        Font font = Minecraft.getInstance().font;

        poseStack.pushPose();
        poseStack.translate(0, entity.getBbHeight() + 0.6, 0);
        poseStack.mulPose(Minecraft.getInstance().getEntityRenderDispatcher().cameraOrientation());
        poseStack.scale(-0.025f, -0.025f, 0.025f);

        int textWidth = font.width(speech);
        int halfWidth = textWidth / 2;
        font.drawInBatch(speech, -halfWidth, 0, 0xFFFF55, true, poseStack.last().pose(), buffer, Font.DisplayMode.NORMAL, 0x80000000, 0xF000F0);
        poseStack.popPose();
    }
}
