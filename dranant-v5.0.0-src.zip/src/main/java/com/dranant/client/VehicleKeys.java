package com.dranant.client;

import com.dranant.network.CarControlPayload;
import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import org.lwjgl.glfw.GLFW;

public class VehicleKeys {
    public static KeyMapping KEY_HORN;
    public static KeyMapping KEY_LIGHTS;
    public static KeyMapping KEY_DOORS;
    public static KeyMapping KEY_HOOD;
    public static KeyMapping KEY_TRUNK;
    public static KeyMapping KEY_MODE;
    public static KeyMapping KEY_WIPERS;
    public static KeyMapping KEY_ROOF;
    public static KeyMapping KEY_AUTOPILOT;
    public static KeyMapping KEY_LOCK;

    public static void register(RegisterKeyMappingsEvent event) {
        String cat = "key.categories.dranant.vehicles";
        KEY_HORN = new KeyMapping("key.dranant.horn", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H, cat);
        KEY_LIGHTS = new KeyMapping("key.dranant.lights", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_L, cat);
        KEY_DOORS = new KeyMapping("key.dranant.doors", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G, cat);
        KEY_HOOD = new KeyMapping("key.dranant.hood", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, cat);
        KEY_TRUNK = new KeyMapping("key.dranant.trunk", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, cat);
        KEY_MODE = new KeyMapping("key.dranant.mode", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_M, cat);
        KEY_WIPERS = new KeyMapping("key.dranant.wipers", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_V, cat);
        KEY_ROOF = new KeyMapping("key.dranant.roof", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_O, cat);
        KEY_AUTOPILOT = new KeyMapping("key.dranant.autopilot", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_U, cat);
        KEY_LOCK = new KeyMapping("key.dranant.lock", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_P, cat);

        event.register(KEY_HORN);
        event.register(KEY_LIGHTS);
        event.register(KEY_DOORS);
        event.register(KEY_HOOD);
        event.register(KEY_TRUNK);
        event.register(KEY_MODE);
        event.register(KEY_WIPERS);
        event.register(KEY_ROOF);
        event.register(KEY_AUTOPILOT);
        event.register(KEY_LOCK);
    }

    public static void onKeyInput(InputEvent.Key event) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;

        if (KEY_HORN.consumeClick()) sendAction(0);
        else if (KEY_LIGHTS.consumeClick()) sendAction(1);
        else if (KEY_DOORS.consumeClick()) sendAction(2);
        else if (KEY_HOOD.consumeClick()) sendAction(3);
        else if (KEY_TRUNK.consumeClick()) sendAction(4);
        else if (KEY_MODE.consumeClick()) sendAction(5);
        else if (KEY_WIPERS.consumeClick()) sendAction(6);
        else if (KEY_ROOF.consumeClick()) sendAction(7);
        else if (KEY_AUTOPILOT.consumeClick()) sendAction(8);
        else if (KEY_LOCK.consumeClick()) sendAction(9);
    }

    private static void sendAction(int action) {
        PacketDistributor.sendToServer(new CarControlPayload(action));
    }
}
