package com.dranant.client.model;

import com.dranant.DoctorAnantMod;
import com.dranant.entity.SupercarEntity;
import com.dranant.entity.SupercarVariant;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

public class SupercarModel extends HierarchicalModel<SupercarEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(DoctorAnantMod.id("supercar"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart hood;
    private final ModelPart trunk;
    private final ModelPart doorL;
    private final ModelPart doorR;
    private final ModelPart steeringWheel;
    private final ModelPart wheelFl;
    private final ModelPart wheelFlSpin;
    private final ModelPart wheelFr;
    private final ModelPart wheelFrSpin;
    private final ModelPart wheelRl;
    private final ModelPart wheelRlSpin;
    private final ModelPart wheelRr;
    private final ModelPart wheelRrSpin;
    private final ModelPart wiper;
    private final ModelPart roof;

    public SupercarModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.hood = this.body.getChild("hood");
        this.trunk = this.body.getChild("trunk");
        this.doorL = this.body.getChild("door_l");
        this.doorR = this.body.getChild("door_r");
        this.roof = this.body.getChild("roof");
        this.steeringWheel = this.body.getChild("steer").getChild("steering_wheel");
        this.wiper = this.body.getChild("wiper");

        this.wheelFl = root.getChild("wheel_fl");
        this.wheelFlSpin = this.wheelFl.getChild("wheel_fl_spin");
        this.wheelFr = root.getChild("wheel_fr");
        this.wheelFrSpin = this.wheelFr.getChild("wheel_fr_spin");
        this.wheelRl = root.getChild("wheel_rl");
        this.wheelRlSpin = this.wheelRl.getChild("wheel_rl_spin");
        this.wheelRr = root.getChild("wheel_rr");
        this.wheelRrSpin = this.wheelRr.getChild("wheel_rr_spin");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // Main Car Body (solid, enclosed cabin)
        PartDefinition body = root.addOrReplaceChild("body", CubeListBuilder.create()
                // Chassis & Lower Floor
                .texOffs(0, 0).addBox(-16.0F, -8.0F, -32.0F, 32.0F, 8.0F, 64.0F)
                // Front Bumper & Air Dam
                .texOffs(0, 72).addBox(-15.0F, -6.0F, -38.0F, 30.0F, 6.0F, 6.0F)
                // Dashboard & Windshield Frame
                .texOffs(72, 72).addBox(-14.0F, -14.0F, -16.0F, 28.0F, 6.0F, 12.0F)
                // Rear Deck & Engine Cover
                .texOffs(0, 144).addBox(-15.0F, -11.0F, 10.0F, 30.0F, 8.0F, 22.0F)
                // Solid Seats (Driver & Passenger Buckets)
                .texOffs(104, 144).addBox(-13.0F, -12.0F, -8.0F, 11.0F, 10.0F, 12.0F)
                .texOffs(104, 144).addBox(2.0F, -12.0F, -8.0F, 11.0F, 10.0F, 12.0F),
                PartPose.offset(0.0F, 18.0F, 0.0F));

        // Enclosed Roof (removable/openable for convertible mode)
        body.addOrReplaceChild("roof", CubeListBuilder.create()
                .texOffs(0, 200).addBox(-14.0F, -18.0F, -6.0F, 28.0F, 4.0F, 20.0F),
                PartPose.ZERO);

        // Windshield Wipers
        body.addOrReplaceChild("wiper", CubeListBuilder.create()
                .texOffs(0, 90).addBox(-10.0F, -15.0F, -15.0F, 20.0F, 1.0F, 1.0F),
                PartPose.ZERO);

        // Hood (Bonnet)
        body.addOrReplaceChild("hood", CubeListBuilder.create()
                .texOffs(128, 0).addBox(-14.0F, -2.0F, -24.0F, 28.0F, 3.0F, 24.0F),
                PartPose.offset(0.0F, -7.0F, -8.0F));

        // Trunk (Boot)
        body.addOrReplaceChild("trunk", CubeListBuilder.create()
                .texOffs(128, 27).addBox(-13.0F, -2.0F, 0.0F, 26.0F, 3.0F, 20.0F),
                PartPose.offset(0.0F, -9.0F, 12.0F));

        // Left Door
        body.addOrReplaceChild("door_l", CubeListBuilder.create()
                .texOffs(128, 50).addBox(-1.0F, -9.0F, -12.0F, 2.0F, 10.0F, 24.0F),
                PartPose.offset(-16.0F, -5.0F, 0.0F));

        // Right Door
        body.addOrReplaceChild("door_r", CubeListBuilder.create()
                .texOffs(128, 84).addBox(-1.0F, -9.0F, -12.0F, 2.0F, 10.0F, 24.0F),
                PartPose.offset(16.0F, -5.0F, 0.0F));

        // Steering Assembly
        PartDefinition steer = body.addOrReplaceChild("steer", CubeListBuilder.create(),
                PartPose.offset(-7.0F, -11.0F, -10.0F));
        steer.addOrReplaceChild("steering_wheel", CubeListBuilder.create()
                .texOffs(180, 50).addBox(-3.5F, -3.5F, -1.0F, 7.0F, 7.0F, 2.0F),
                PartPose.ZERO);

        // Wheels
        addWheel(root, "wheel_fl", -17.0F, 20.0F, -20.0F);
        addWheel(root, "wheel_fr", 17.0F, 20.0F, -20.0F);
        addWheel(root, "wheel_rl", -17.0F, 20.0F, 20.0F);
        addWheel(root, "wheel_rr", 17.0F, 20.0F, 20.0F);

        return LayerDefinition.create(mesh, 256, 256);
    }

    private static void addWheel(PartDefinition root, String name, float x, float y, float z) {
        PartDefinition wheel = root.addOrReplaceChild(name, CubeListBuilder.create(), PartPose.offset(x, y, z));
        wheel.addOrReplaceChild(name + "_spin", CubeListBuilder.create()
                .texOffs(180, 0).addBox(-3.0F, -6.0F, -6.0F, 6.0F, 12.0F, 12.0F),
                PartPose.ZERO);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(SupercarEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        pose(entity, ageInTicks - entity.tickCount);
    }

    public void pose(SupercarEntity entity, float partialTicks) {
        this.root.resetPose();

        float wheelSpin = Mth.lerp(partialTicks, entity.wheelSpinO, entity.wheelSpin);
        this.wheelFlSpin.xRot = wheelSpin;
        this.wheelFrSpin.xRot = wheelSpin;
        this.wheelRlSpin.xRot = wheelSpin;
        this.wheelRrSpin.xRot = wheelSpin;

        // Steering: Correct 1:1 steering angle (not inverted!)
        float steer = Mth.lerp(partialTicks, entity.visualSteerO, entity.visualSteer);
        this.wheelFl.yRot = steer * 0.55F;
        this.wheelFr.yRot = steer * 0.55F;
        this.steeringWheel.zRot = steer * 2.5F;

        // Doors & Animations
        SupercarVariant variant = entity.getVariant();
        float openL = Mth.lerp(partialTicks, entity.partOpenO[SupercarEntity.PART_DOOR_LEFT], entity.partOpen[SupercarEntity.PART_DOOR_LEFT]);
        float openR = Mth.lerp(partialTicks, entity.partOpenO[SupercarEntity.PART_DOOR_RIGHT], entity.partOpen[SupercarEntity.PART_DOOR_RIGHT]);

        poseDoor(this.doorL, -1, openL, variant);
        poseDoor(this.doorR, 1, openR, variant);

        // Convertible Roof toggle
        boolean roofOpen = entity.isPartOpen(SupercarEntity.PART_ROOF);
        this.roof.visible = !roofOpen;

        // Windshield Wipers
        this.wiper.zRot = entity.wiperAngle;
    }

    private void poseDoor(ModelPart door, int side, float openProgress, SupercarVariant variant) {
        if (openProgress <= 0.001F) return;

        switch (variant.doorStyle()) {
            case SCISSOR -> {
                // Lamborghini style scissor doors: swing up vertically!
                door.xRot = -openProgress * 1.15F;
                door.yRot = side * openProgress * 0.25F;
            }
            case GULLWING -> {
                // Gullwing: swing up and out like wings!
                door.zRot = side * -openProgress * 1.35F;
            }
            default -> {
                // Conventional out-swinging doors
                door.yRot = side * openProgress * 0.95F;
            }
        }
    }
}
