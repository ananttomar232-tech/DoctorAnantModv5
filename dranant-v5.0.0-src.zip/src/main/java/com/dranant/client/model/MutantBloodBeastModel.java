package com.dranant.client.model;

import com.dranant.entity.MutantBloodBeastEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

public class MutantBloodBeastModel extends HierarchicalModel<MutantBloodBeastEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(ResourceLocation.fromNamespaceAndPath("dranant", "mutant_blood_beast"), "main");

    private final ModelPart root;
    private final ModelPart body;
    private final ModelPart head;
    private final ModelPart leftArm;
    private final ModelPart rightArm;
    private final ModelPart leftLeg;
    private final ModelPart rightLeg;

    public MutantBloodBeastModel(ModelPart root) {
        this.root = root;
        this.body = root.getChild("body");
        this.head = body.getChild("head");
        this.leftArm = root.getChild("left_arm");
        this.rightArm = root.getChild("right_arm");
        this.leftLeg = root.getChild("left_leg");
        this.rightLeg = root.getChild("right_leg");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition body = root.addOrReplaceChild("body",
            CubeListBuilder.create().texOffs(0, 40).addBox(-7.0f, -15.0f, -6.0f, 14.0f, 16.0f, 12.0f),
            PartPose.offset(0.0f, 10.0f, 0.0f));

        body.addOrReplaceChild("head",
            CubeListBuilder.create().texOffs(0, 0).addBox(-4.0f, -8.0f, -4.0f, 8.0f, 8.0f, 8.0f),
            PartPose.offset(0.0f, -15.0f, -3.0f));

        root.addOrReplaceChild("right_arm",
            CubeListBuilder.create().texOffs(40, 0).addBox(-3.0f, -2.0f, -2.0f, 6.0f, 18.0f, 6.0f),
            PartPose.offset(-10.0f, 2.0f, 0.0f));

        root.addOrReplaceChild("left_arm",
            CubeListBuilder.create().texOffs(40, 0).mirror().addBox(-3.0f, -2.0f, -2.0f, 6.0f, 18.0f, 6.0f),
            PartPose.offset(10.0f, 2.0f, 0.0f));

        root.addOrReplaceChild("right_leg",
            CubeListBuilder.create().texOffs(0, 16).addBox(-3.0f, 0.0f, -3.0f, 6.0f, 14.0f, 6.0f),
            PartPose.offset(-4.0f, 10.0f, 0.0f));

        root.addOrReplaceChild("left_leg",
            CubeListBuilder.create().texOffs(0, 16).mirror().addBox(-3.0f, 0.0f, -3.0f, 6.0f, 14.0f, 6.0f),
            PartPose.offset(4.0f, 10.0f, 0.0f));

        return LayerDefinition.create(mesh, 128, 128);
    }

    @Override
    public ModelPart root() { return root; }

    @Override
    public void setupAnim(MutantBloodBeastEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.head.yRot = netHeadYaw * ((float)Math.PI / 180F);
        this.head.xRot = headPitch * ((float)Math.PI / 180F);
        this.rightLeg.xRot = (float)Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
        this.leftLeg.xRot = (float)Math.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.rightArm.xRot = (float)Math.cos(limbSwing * 0.6662F + (float)Math.PI) * 1.4F * limbSwingAmount;
        this.leftArm.xRot = (float)Math.cos(limbSwing * 0.6662F) * 1.4F * limbSwingAmount;
    }
}
