package com.dranant.client.model;

import com.dranant.DoctorAnantMod;
import com.dranant.entity.BikeEntity;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

public class BikeModel extends HierarchicalModel<BikeEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(DoctorAnantMod.id("bike"), "main");

    private final ModelPart root;
    private final ModelPart chassis;
    private final ModelPart handle;
    private final ModelPart wheelFront;
    private final ModelPart wheelRear;

    public BikeModel(ModelPart root) {
        this.root = root;
        this.chassis = root.getChild("chassis");
        this.handle = this.chassis.getChild("handle");
        this.wheelFront = this.handle.getChild("wheel_front");
        this.wheelRear = this.chassis.getChild("wheel_rear");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition chassis = root.addOrReplaceChild("chassis", CubeListBuilder.create()
                // Frame & Tank
                .texOffs(0, 0).addBox(-3.0F, -8.0F, -8.0F, 6.0F, 6.0F, 16.0F)
                // Engine & Exhaust
                .texOffs(0, 22).addBox(-2.5F, -2.0F, -4.0F, 5.0F, 6.0F, 10.0F)
                // Seat
                .texOffs(28, 0).addBox(-2.5F, -10.0F, 0.0F, 5.0F, 2.0F, 8.0F),
                PartPose.offset(0.0F, 18.0F, 0.0F));

        PartDefinition handle = chassis.addOrReplaceChild("handle", CubeListBuilder.create()
                // Handlebars
                .texOffs(28, 10).addBox(-7.0F, -14.0F, -10.0F, 14.0F, 2.0F, 2.0F)
                // Front Fork
                .texOffs(0, 38).addBox(-2.0F, -12.0F, -12.0F, 4.0F, 14.0F, 2.0F),
                PartPose.ZERO);

        handle.addOrReplaceChild("wheel_front", CubeListBuilder.create()
                .texOffs(40, 20).addBox(-1.5F, -4.0F, -4.0F, 3.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 2.0F, -11.0F));

        chassis.addOrReplaceChild("wheel_rear", CubeListBuilder.create()
                .texOffs(40, 20).addBox(-1.5F, -4.0F, -4.0F, 3.0F, 8.0F, 8.0F),
                PartPose.offset(0.0F, 2.0F, 8.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(BikeEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root.resetPose();

        float partialTicks = ageInTicks - entity.tickCount;
        float rot = Mth.lerp(partialTicks, entity.wheelRotO, entity.wheelRot);
        this.wheelFront.xRot = rot;
        this.wheelRear.xRot = rot;

        // Steering: NOT inverted!
        this.handle.yRot = entity.turnInput * 0.45F;

        // Dynamic Lean in corners!
        this.root.zRot = (float) Math.toRadians(entity.lean);

        // Wheelie angle!
        this.root.xRot = (float) Math.toRadians(-entity.wheelie);
    }
}
