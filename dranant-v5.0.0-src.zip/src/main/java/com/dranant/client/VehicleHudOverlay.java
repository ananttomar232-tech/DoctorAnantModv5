package com.dranant.client;

import com.dranant.entity.SupercarEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.world.entity.player.Player;

public class VehicleHudOverlay {
    public static void render(GuiGraphics g, float partialTicks) {
        Minecraft mc = Minecraft.getInstance();
        Player p = mc.player;
        if (p == null || !(p.getVehicle() instanceof SupercarEntity car)) return;

        int width = mc.getWindow().getGuiScaledWidth();
        int height = mc.getWindow().getGuiScaledHeight();

        int kmh = car.getSpeedKmh();
        String gear = car.getGearName();
        String mode = car.getDriveModeName();

        int hudX = width - 130;
        int hudY = height - 60;

        // Background card
        g.fill(hudX - 10, hudY - 10, hudX + 120, hudY + 50, 0xAA000000);

        // Speed readout
        g.drawString(mc.font, "§f§l" + kmh + " §7KM/H", hudX, hudY, 0xFFFFFF, true);

        // Gear & RPM
        g.drawString(mc.font, "§eGEAR: §a" + gear + " §8| §c" + (int)car.rpm + " RPM", hudX, hudY + 14, 0xFFFFFF, true);

        // Mode badge
        int modeColor = switch (car.getDriveMode()) {
            case 0 -> 0x55FFFF; // Blue
            case 1 -> 0xFFAA00; // Gold
            case 2 -> 0xFF5555; // Red
            case 3 -> 0xAA00AA; // Purple
            default -> 0xFFFFFF;
        };
        g.drawString(mc.font, "MODE: " + mode, hudX, hudY + 28, modeColor, true);

        // Autopilot & Lock indicator
        String status = (car.isAutopilot() ? "§a[AUTO] " : "") + (car.isLocked() ? "§c[LOCKED]" : "§2[OPEN]");
        g.drawString(mc.font, status, hudX, hudY + 40, 0xFFFFFF, true);
    }
}
