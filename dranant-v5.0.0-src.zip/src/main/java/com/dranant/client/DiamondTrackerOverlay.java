package com.dranant.client;

import com.dranant.counter.ClientDiamondData;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;

public class DiamondTrackerOverlay implements LayeredDraw.Layer {
    private static final ResourceLocation DIAMOND = ResourceLocation.fromNamespaceAndPath("minecraft", "textures/item/diamond.png");

    @Override
    public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || !ClientDiamondData.isVisible()) return;

        int width = mc.getWindow().getGuiScaledWidth();
        int x = width - 120;
        int y = 10;

        graphics.blit(DIAMOND, x, y, 0, 0, 16, 16, 16, 16);
        long diamonds = ClientDiamondData.displayValue();
        String text = String.format("%,d", diamonds);
        graphics.drawString(mc.font, text, x + 20, y + 4, 0x55FFFF, true);
    }
}
