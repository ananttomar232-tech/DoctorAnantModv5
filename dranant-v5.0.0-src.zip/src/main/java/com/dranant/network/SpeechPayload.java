package com.dranant.network;

import com.dranant.DoctorAnantMod;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record SpeechPayload(int entityId, String text) implements CustomPacketPayload {
    public static final Type<SpeechPayload> TYPE = new Type<>(DoctorAnantMod.id("speech"));
    public static final StreamCodec<ByteBuf, SpeechPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.INT, SpeechPayload::entityId,
            ByteBufCodecs.STRING_UTF8, SpeechPayload::text,
            SpeechPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(SpeechPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientSpeechData.add(payload.entityId(), payload.text()));
    }
}
