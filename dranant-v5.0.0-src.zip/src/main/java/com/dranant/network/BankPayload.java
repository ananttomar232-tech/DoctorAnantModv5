package com.dranant.network;

import com.dranant.DoctorAnantMod;
import com.dranant.counter.ClientDiamondData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record BankPayload(long diamonds) implements CustomPacketPayload {
    public static final Type<BankPayload> TYPE = new Type<>(DoctorAnantMod.id("bank_sync"));
    public static final StreamCodec<ByteBuf, BankPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_LONG, BankPayload::diamonds,
            BankPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }

    public static void handle(BankPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientDiamondData.set(payload.diamonds()));
    }
}
