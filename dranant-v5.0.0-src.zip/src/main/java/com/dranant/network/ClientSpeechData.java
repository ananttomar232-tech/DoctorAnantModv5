package com.dranant.network;

import java.util.HashMap;
import java.util.Map;

public class ClientSpeechData {
    public static final Map<Integer, Bubble> BUBBLES = new HashMap<>();

    public record Bubble(String text, long expireTime) {}

    public static void add(int entityId, String text) {
        BUBBLES.put(entityId, new Bubble(text, System.currentTimeMillis() + 4000));
    }

    public static String get(int entityId) {
        Bubble b = BUBBLES.get(entityId);
        if (b != null) {
            if (System.currentTimeMillis() < b.expireTime) return b.text;
            else BUBBLES.remove(entityId);
        }
        return null;
    }
}
