package com.dranant.network;

import com.dranant.DoctorAnantMod;
import com.dranant.entity.SupercarEntity;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.world.entity.player.Player;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public record CarControlPayload(int action) implements CustomPacketPayload {
    public static final Type<CarControlPayload> TYPE = new Type<>(DoctorAnantMod.id("car_control"));
    public static final StreamCodec<ByteBuf, CarControlPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.INT, CarControlPayload::action,
            CarControlPayload::new
    );

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(CarControlPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> {
            Player player = context.player();
            if (player.getVehicle() instanceof SupercarEntity car) {
                car.handleControl(payload.action(), player);
            }
        });
    }
}
