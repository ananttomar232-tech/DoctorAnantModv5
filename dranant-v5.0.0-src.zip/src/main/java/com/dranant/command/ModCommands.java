package com.dranant.command;

import com.dranant.block.ClinicSummonerBlock;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class ModCommands {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        // Register /clear clinic
        dispatcher.register(Commands.literal("clear")
                .then(Commands.literal("clinic")
                        .executes(ctx -> executeClearClinic(ctx.getSource()))));

        // Also register /dranant clear clinic
        dispatcher.register(Commands.literal("dranant")
                .then(Commands.literal("clear")
                        .then(Commands.literal("clinic")
                                .executes(ctx -> executeClearClinic(ctx.getSource())))));
    }

    private static int executeClearClinic(CommandSourceStack source) {
        if (!(source.getEntity() instanceof net.minecraft.world.entity.player.Player player)) {
            source.sendFailure(Component.literal("Player only command."));
            return 0;
        }

        ServerLevel level = source.getLevel();
        BlockPos playerPos = player.blockPosition();
        int radius = 48;
        int clearedBlocks = 0;

        BlockPos.MutableBlockPos mpos = new BlockPos.MutableBlockPos();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = -10; dy <= 40; dy++) {
                    mpos.set(playerPos.getX() + dx, playerPos.getY() + dy, playerPos.getZ() + dz);
                    BlockState st = level.getBlockState(mpos);

                    // CRITICAL: Keep the clinic_summoner block!
                    if (st.getBlock() instanceof ClinicSummonerBlock) {
                        continue;
                    }

                    // Remove clinic structure blocks (concrete, quartz, glass, iron bars, hospital furniture)
                    if (isClinicBuildingBlock(st)) {
                        if (dy < 0) {
                            // Restore ground terrain to clean grass / dirt
                            level.setBlock(mpos, Blocks.GRASS_BLOCK.defaultBlockState(), 3);
                        } else {
                            // Clear air above
                            level.setBlock(mpos, Blocks.AIR.defaultBlockState(), 3);
                        }
                        clearedBlocks++;
                    }
                }
            }
        }

        source.sendSuccess(() -> Component.literal("§a[Dr. Anant Clinic] Cleared " + clearedBlocks + " clinic structure blocks! Terrain restored & summoner block preserved."), true);
        return 1;
    }

    private static boolean isClinicBuildingBlock(BlockState state) {
        return state.is(Blocks.WHITE_CONCRETE) || state.is(Blocks.LIGHT_BLUE_CONCRETE) ||
               state.is(Blocks.CYAN_CONCRETE) || state.is(Blocks.SMOOTH_QUARTZ) ||
               state.is(Blocks.QUARTZ_PILLAR) || state.is(Blocks.GLASS) ||
               state.is(Blocks.SEA_LANTERN) || state.is(Blocks.IRON_BARS) ||
               state.getBlock() instanceof com.dranant.block.FurnitureBlock ||
               state.getBlock() instanceof com.dranant.block.ExaminationBedBlock ||
               state.getBlock() instanceof com.dranant.block.StretcherBlock;
    }
}
