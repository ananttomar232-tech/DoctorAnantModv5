package com.dranant.entity;

import com.dranant.DoctorAnantMod;
import net.minecraft.resources.ResourceLocation;

public enum SupercarVariant {
    VELOCE("veloce", "Anant Veloce V12", 50, 2.7, 0.040, 0.32, DoorStyle.SCISSOR, 0xC8102E, 850, "2.8 s"),
    GT("gt", "Anant Stradale GT", 35, 2.4, 0.038, 0.38, DoorStyle.CONVENTIONAL, 0x3C8D0D, 650, "3.2 s"),
    PHANTOM("phantom", "Anant Phantom Noir", 75, 3.0, 0.045, 0.35, DoorStyle.GULLWING, 0x1A1A1A, 1020, "2.4 s");

    private final String id;
    private final String displayName;
    private final int diamondPrice;
    private final double topSpeed;
    private final double accel;
    private final double grip;
    private final DoorStyle doorStyle;
    private final int color;
    private final int horsepower;
    private final String zeroToHundred;
    private final ResourceLocation texture;

    SupercarVariant(String id, String displayName, int diamondPrice, double topSpeed, double accel, double grip,
                    DoorStyle doorStyle, int color, int horsepower, String zeroToHundred) {
        this.id = id;
        this.displayName = displayName;
        this.diamondPrice = diamondPrice;
        this.topSpeed = topSpeed;
        this.accel = accel;
        this.grip = grip;
        this.doorStyle = doorStyle;
        this.color = color;
        this.horsepower = horsepower;
        this.zeroToHundred = zeroToHundred;
        this.texture = DoctorAnantMod.id("textures/entity/supercar/" + id + ".png");
    }

    public String id() { return id; }
    public String displayName() { return displayName; }
    public int diamondPrice() { return diamondPrice; }
    public double topSpeed() { return topSpeed; }
    public double accel() { return accel; }
    public double grip() { return grip; }
    public DoorStyle doorStyle() { return doorStyle; }
    public int color() { return color; }
    public int horsepower() { return horsepower; }
    public String zeroToHundred() { return zeroToHundred; }
    public ResourceLocation texture() { return texture; }

    public int topSpeedKmh() {
        return (int) Math.round(this.topSpeed * 72.0);
    }

    public static SupercarVariant byOrdinal(int ord) {
        SupercarVariant[] values = values();
        return values[Math.floorMod(ord, values.length)];
    }

    public enum DoorStyle {
        CONVENTIONAL, SCISSOR, GULLWING
    }
}
