package com.dranant.entity;

import com.dranant.registry.ModEntities;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

public class SidekickBulletEntity extends ThrowableItemProjectile {
    public static final float DAMAGE = 18.0f; // UPGRADED FOR V5

    public SidekickBulletEntity(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public SidekickBulletEntity(Level level, LivingEntity shooter) {
        super(ModEntities.SIDEKICK_BULLET.get(), shooter, level);
    }

    @Override
    protected Item getDefaultItem() {
        return Items.IRON_NUGGET;
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        Entity owner = this.getOwner();
        if (target != owner && !(target instanceof Player) && !(target instanceof SidekickEntity)) {
            target.hurt(this.damageSources().thrown(this, owner), DAMAGE);
        }
        if (!this.level().isClientSide()) {
            this.discard();
        }
    }
}
