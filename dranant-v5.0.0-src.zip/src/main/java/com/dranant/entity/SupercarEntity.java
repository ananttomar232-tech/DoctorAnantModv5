package com.dranant.entity;

import com.dranant.DoctorAnantMod;
import com.dranant.counter.DiamondBank;
import com.dranant.registry.ModEntities;
import com.dranant.registry.ModItems;
import com.dranant.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Explosion;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class SupercarEntity extends Entity {
    public static final int PART_DOOR_LEFT = 0;
    public static final int PART_DOOR_RIGHT = 1;
    public static final int PART_HOOD = 2;
    public static final int PART_TRUNK = 3;
    public static final int PART_ROOF = 4;

    public static final int MODE_COMFORT = 0;
    public static final int MODE_SPORT = 1;
    public static final int MODE_TRACK = 2;
    public static final int MODE_DRIFT = 3;

    private static final EntityDataAccessor<Integer> DATA_VARIANT = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PARTS = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_LIGHTS = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_SHOWROOM = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_TURNTABLE = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_LOCKED = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_DRIVE_MODE = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_AUTOPILOT = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_WIPERS = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Boolean> DATA_OWNED = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<String> DATA_OWNER = SynchedEntityData.defineId(SupercarEntity.class, EntityDataSerializers.STRING);

    public double speed = 0.0;
    public double velX = 0.0;
    public double velZ = 0.0;
    public float steer = 0.0F;
    public double nitro = 1.0;
    public boolean nitroActive = false;
    public boolean braking = false;
    public int gear = 0; // 0=P, 1=R, 2=N, 3=D1, 4=D2, 5=D3, 6=D4, 7=D5, 8=D6
    public float rpm = 1000.0F;
    public float drift = 0.0F;
    public int crashShake = 0;

    public float[] partOpen = new float[5];
    public float[] partOpenO = new float[5];
    public float wheelSpin = 0.0F;
    public float wheelSpinO = 0.0F;
    public float visualSteer = 0.0F;
    public float visualSteerO = 0.0F;
    public float wiperAngle = 0.0F;

    private int autoCloseTicks = 0;
    private long zeroToHundredStartTime = 0;
    private boolean timingZeroToHundred = false;
    private String lastRecordedZeroToHundred = "N/A";

    public SupercarEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_VARIANT, 0);
        builder.define(DATA_PARTS, 0);
        builder.define(DATA_LIGHTS, false);
        builder.define(DATA_SHOWROOM, false);
        builder.define(DATA_TURNTABLE, false);
        builder.define(DATA_LOCKED, false);
        builder.define(DATA_DRIVE_MODE, MODE_SPORT);
        builder.define(DATA_AUTOPILOT, false);
        builder.define(DATA_WIPERS, false);
        builder.define(DATA_OWNED, false);
        builder.define(DATA_OWNER, "");
    }

    public SupercarVariant getVariant() {
        return SupercarVariant.byOrdinal(this.entityData.get(DATA_VARIANT));
    }

    public void setVariant(SupercarVariant variant) {
        this.entityData.set(DATA_VARIANT, variant.ordinal());
    }

    public boolean isPartOpen(int part) {
        return (this.entityData.get(DATA_PARTS) & (1 << part)) != 0;
    }

    public void setPartOpen(int part, boolean open) {
        int mask = this.entityData.get(DATA_PARTS);
        if (open) mask |= (1 << part);
        else mask &= ~(1 << part);
        this.entityData.set(DATA_PARTS, mask);
    }

    public boolean isLocked() { return this.entityData.get(DATA_LOCKED); }
    public void setLocked(boolean locked) { this.entityData.set(DATA_LOCKED, locked); }

    public int getDriveMode() { return this.entityData.get(DATA_DRIVE_MODE); }
    public void setDriveMode(int mode) { this.entityData.set(DATA_DRIVE_MODE, mode % 4); }

    public boolean isAutopilot() { return this.entityData.get(DATA_AUTOPILOT); }
    public void setAutopilot(boolean ap) { this.entityData.set(DATA_AUTOPILOT, ap); }

    public boolean areWipersOn() { return this.entityData.get(DATA_WIPERS); }
    public void setWipers(boolean wipers) { this.entityData.set(DATA_WIPERS, wipers); }

    public boolean isShowroomCar() { return this.entityData.get(DATA_SHOWROOM); }
    public void setShowroom(boolean showroom, boolean turntable) {
        this.entityData.set(DATA_SHOWROOM, showroom);
        this.entityData.set(DATA_TURNTABLE, turntable);
    }

    public boolean isOwned() { return this.entityData.get(DATA_OWNED); }
    public void setOwned(boolean owned, String ownerName) {
        this.entityData.set(DATA_OWNED, owned);
        this.entityData.set(DATA_OWNER, ownerName);
    }
    public String getOwnerName() { return this.entityData.get(DATA_OWNER); }

    public boolean lightsOn() { return this.entityData.get(DATA_LIGHTS); }

    public int getSpeedKmh() {
        return (int) Math.round(Math.abs(this.speed) * 72.0);
    }

    public String getDriveModeName() {
        return switch (getDriveMode()) {
            case MODE_COMFORT -> "COMFORT";
            case MODE_SPORT -> "SPORT";
            case MODE_TRACK -> "TRACK";
            case MODE_DRIFT -> "DRIFT";
            default -> "SPORT";
        };
    }

    public String getGearName() {
        return switch (this.gear) {
            case 0 -> "P";
            case 1 -> "R";
            case 2 -> "N";
            case 3 -> "D1";
            case 4 -> "D2";
            case 5 -> "D3";
            case 6 -> "D4";
            case 7 -> "D5";
            case 8 -> "D6";
            default -> "D";
        };
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (player.isShiftKeyDown()) {
            // Shift click toggles Lock
            if (isOwned() && !this.level().isClientSide) {
                boolean newLock = !isLocked();
                setLocked(newLock);
                playLocalSound(ModSounds.CAR_LOCK.get(), 1.0F, newLock ? 1.2F : 0.9F);
                player.displayClientMessage(Component.literal(newLock ? "§c[Locked] Vehicle secured." : "§a[Unlocked] Vehicle ready."), true);
                return InteractionResult.SUCCESS;
            }
        }

        // Showroom Purchasing Logic
        if (isShowroomCar()) {
            if (!this.level().isClientSide) {
                int price = getVariant().diamondPrice();
                ItemStack held = player.getItemInHand(hand);
                if (held.is(Items.DIAMOND) && held.getCount() >= price) {
                    held.shrink(price);
                    setShowroom(false, false);
                    setOwned(true, "Anant Motors");
                    setLocked(false);
                    playLocalSound(ModSounds.CASH_REGISTER_CHIME.get(), 1.0F, 1.0F);
                    player.displayClientMessage(Component.literal("§a§lCONGRATULATIONS!§r §ePurchased " + getVariant().displayName() + " for " + price + " Diamonds! Registered to: §6Anant Motors"), false);
                    return InteractionResult.SUCCESS;
                } else {
                    player.displayClientMessage(Component.literal("§6§l" + getVariant().displayName() + "§r - §ePrice: " + price + " Diamonds. (Hold " + price + " Diamonds to purchase)"), true);
                    return InteractionResult.CONSUME;
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // Lock check
        if (isLocked()) {
            if (!this.level().isClientSide) {
                playLocalSound(ModSounds.CAR_LOCK.get(), 0.8F, 0.6F);
                player.displayClientMessage(Component.literal("§c[!] The vehicle is locked! Shift+Right-Click to unlock."), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // Door Requirement Check: Cannot sit without opening car door!
        boolean driverDoorOpen = isPartOpen(PART_DOOR_LEFT);
        boolean passengerDoorOpen = isPartOpen(PART_DOOR_RIGHT);
        
        if (!this.level().isClientSide) {
            // If neither door is open, clicking opens the driver door first!
            if (!driverDoorOpen && !passengerDoorOpen) {
                setPartOpen(PART_DOOR_LEFT, true);
                playLocalSound(ModSounds.CAR_DOOR.get(), 1.0F, 1.0F);
                this.autoCloseTicks = 40;
                player.displayClientMessage(Component.literal("§a[!] Door opened. Right-click again to sit inside."), true);
                return InteractionResult.SUCCESS;
            }

            // Door is open -> Player can now mount!
            if (this.getPassengers().isEmpty()) {
                player.startRiding(this);
                this.autoCloseTicks = 30; // Will auto close door shortly
                return InteractionResult.SUCCESS;
            } else if (this.getPassengers().size() == 1) {
                if (passengerDoorOpen) {
                    player.startRiding(this);
                    this.autoCloseTicks = 30;
                    return InteractionResult.SUCCESS;
                } else {
                    setPartOpen(PART_DOOR_RIGHT, true);
                    playLocalSound(ModSounds.CAR_DOOR.get(), 1.0F, 1.0F);
                    player.displayClientMessage(Component.literal("§a[!] Passenger door opened. Right-click to enter."), true);
                    return InteractionResult.SUCCESS;
                }
            } else {
                player.displayClientMessage(Component.literal("§cBoth seats are full!"), true);
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    public void handleControl(int action, Player player) {
        switch (action) {
            case 0 -> { // Horn
                playLocalSound(ModSounds.CAR_HORN.get(), 1.2F, 1.0F);
            }
            case 1 -> { // Lights
                this.entityData.set(DATA_LIGHTS, !lightsOn());
            }
            case 2 -> { // Doors
                boolean open = !isPartOpen(PART_DOOR_LEFT);
                setPartOpen(PART_DOOR_LEFT, open);
                setPartOpen(PART_DOOR_RIGHT, open);
                playLocalSound(ModSounds.CAR_DOOR.get(), 1.0F, open ? 1.0F : 0.85F);
            }
            case 3 -> { // Hood
                setPartOpen(PART_HOOD, !isPartOpen(PART_HOOD));
            }
            case 4 -> { // Trunk
                setPartOpen(PART_TRUNK, !isPartOpen(PART_TRUNK));
            }
            case 5 -> { // Drive Mode toggle
                setDriveMode(getDriveMode() + 1);
                playLocalSound(ModSounds.CAR_SHIFT.get(), 1.0F, 1.2F);
                player.displayClientMessage(Component.literal("§eDrive Mode: §6§l" + getDriveModeName()), true);
            }
            case 6 -> { // Wipers toggle
                setWipers(!areWipersOn());
                playLocalSound(ModSounds.CAR_WIPER.get(), 0.8F, 1.0F);
            }
            case 7 -> { // Roof toggle
                setPartOpen(PART_ROOF, !isPartOpen(PART_ROOF));
                playLocalSound(ModSounds.CAR_DOOR.get(), 0.9F, 1.2F);
                player.displayClientMessage(Component.literal(isPartOpen(PART_ROOF) ? "§bRoof: OPEN (Convertible)" : "§bRoof: CLOSED"), true);
            }
            case 8 -> { // Autopilot toggle
                setAutopilot(!isAutopilot());
                player.displayClientMessage(Component.literal(isAutopilot() ? "§a[Autopilot: ENGAGED]" : "§c[Autopilot: DISENGAGED]"), true);
            }
            case 9 -> { // Lock toggle
                boolean lk = !isLocked();
                setLocked(lk);
                playLocalSound(ModSounds.CAR_LOCK.get(), 1.0F, lk ? 1.2F : 0.9F);
                player.displayClientMessage(Component.literal(lk ? "§c[Vehicle Locked]" : "§a[Vehicle Unlocked]"), true);
            }
        }
    }

    @Override
    public void tick() {
        super.tick();

        this.wheelSpinO = this.wheelSpin;
        this.visualSteerO = this.visualSteer;
        for (int i = 0; i < 5; i++) {
            this.partOpenO[i] = this.partOpen[i];
            float target = isPartOpen(i) ? 1.0F : 0.0F;
            this.partOpen[i] = Mth.lerp(0.2F, this.partOpen[i], target);
        }

        if (areWipersOn()) {
            this.wiperAngle = (float) Math.sin((this.tickCount * 0.4F)) * 0.8F;
        } else {
            this.wiperAngle = 0.0F;
        }

        if (this.autoCloseTicks > 0) {
            this.autoCloseTicks--;
            if (this.autoCloseTicks == 0) {
                if (isPartOpen(PART_DOOR_LEFT)) setPartOpen(PART_DOOR_LEFT, false);
                if (isPartOpen(PART_DOOR_RIGHT)) setPartOpen(PART_DOOR_RIGHT, false);
                playLocalSound(ModSounds.CAR_DOOR.get(), 0.8F, 0.85F);
            }
        }

        if (this.entityData.get(DATA_TURNTABLE)) {
            this.setYRot(this.getYRot() + 1.0F);
            return;
        }

        drive();
    }

    private void drive() {
        LivingEntity driver = getControllingPassenger();
        boolean hasDriver = driver instanceof Player;

        // Auto-pilot logic
        if (isAutopilot() && hasDriver) {
            runAutopilot();
        }

        float forwardInput = 0.0F;
        float steerInput = 0.0F;
        boolean space = false;

        if (hasDriver && !isAutopilot()) {
            forwardInput = driver.zza; // Forward / Backwards
            // FIX: Minecraft player.xxa: Positive is Left (+1.0), Negative is Right (-1.0)
            // To make Right turn Right and Left turn Left, we NEGATE xxa:
            steerInput = -driver.xxa; 
            space = driver.jumping;
        }

        SupercarVariant v = getVariant();
        int mode = getDriveMode();

        double maxSpeedMod = switch (mode) {
            case MODE_COMFORT -> 0.70;
            case MODE_SPORT -> 1.0;
            case MODE_TRACK -> 1.25;
            case MODE_DRIFT -> 0.95;
            default -> 1.0;
        };

        double accelMod = switch (mode) {
            case MODE_COMFORT -> 0.65;
            case MODE_SPORT -> 1.0;
            case MODE_TRACK -> 1.45;
            case MODE_DRIFT -> 1.15;
            default -> 1.0;
        };

        double gripMod = switch (mode) {
            case MODE_COMFORT -> 1.20;
            case MODE_SPORT -> 1.0;
            case MODE_TRACK -> 1.15;
            case MODE_DRIFT -> 0.40; // Low grip for real drifting!
            default -> 1.0;
        };

        double top = v.topSpeed() * maxSpeedMod;
        double accel = v.accel() * accelMod;

        // Acceleration
        if (forwardInput > 0) {
            if (this.speed < 0) {
                this.speed = Math.min(0, this.speed + accel * 2.0); // braking from reverse
            } else {
                if (!timingZeroToHundred && this.speed < 0.05) {
                    timingZeroToHundred = true;
                    zeroToHundredStartTime = System.currentTimeMillis();
                }
                this.speed = Math.min(top, this.speed + accel);
            }
        } else if (forwardInput < 0) {
            if (this.speed > 0) {
                this.speed = Math.max(0, this.speed - accel * 2.5); // braking
                this.braking = true;
            } else {
                this.speed = Math.max(-top * 0.35, this.speed - accel * 0.8);
            }
        } else {
            this.speed *= 0.96;
            this.braking = false;
        }

        if (space) {
            this.speed *= 0.91; // Handbrake
            this.braking = true;
        }

        // Measure 0-100 km/h (100 km/h = 1.389 speed)
        if (timingZeroToHundred && getSpeedKmh() >= 100) {
            timingZeroToHundred = false;
            double sec = (System.currentTimeMillis() - zeroToHundredStartTime) / 1000.0;
            lastRecordedZeroToHundred = String.format("%.2f s", sec);
            if (driver instanceof Player p) {
                p.displayClientMessage(Component.literal("§e⚡ 0-100 km/h: §a§l" + lastRecordedZeroToHundred + " §r(" + getDriveModeName() + " Mode)"), false);
            }
        }

        // Steering & Yaw Application
        // Turning speed slows turn rate at high speeds for stability
        float turnSensitivity = (float) (2.8F * (1.0 - Math.min(0.55, Math.abs(this.speed) / top * 0.5)));
        float targetVisualSteer = steerInput * 0.65F;
        this.visualSteer = Mth.lerp(0.25F, this.visualSteer, targetVisualSteer);

        if (Math.abs(this.speed) > 0.01) {
            float yawDelta = steerInput * turnSensitivity * (float) Math.signum(this.speed);
            // CRITICAL FIX: Add yawDelta so D (steerInput > 0) increases Y-Rot (turns Right)
            this.setYRot(this.getYRot() + yawDelta);
        }

        // Drift calculations
        if (mode == MODE_DRIFT && Math.abs(steerInput) > 0.3 && Math.abs(this.speed) > 0.4) {
            this.drift = Mth.lerp(0.3F, this.drift, steerInput * 1.5F);
            // Spawn drift tire smoke
            if (this.level() instanceof ServerLevel sl) {
                Vec3 rearL = this.position().add(-Math.sin(Math.toRadians(getYRot() + 140)), 0.1, Math.cos(Math.toRadians(getYRot() + 140)));
                Vec3 rearR = this.position().add(-Math.sin(Math.toRadians(getYRot() - 140)), 0.1, Math.cos(Math.toRadians(getYRot() - 140)));
                sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, rearL.x, rearL.y, rearL.z, 2, 0.05, 0.05, 0.05, 0.01);
                sl.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE, rearR.x, rearR.y, rearR.z, 2, 0.05, 0.05, 0.05, 0.01);
            }
        } else {
            this.drift = Mth.lerp(0.2F, this.drift, 0.0F);
        }

        // Velocity vector
        double rad = Math.toRadians(this.getYRot() + (this.drift * 12.0F));
        this.velX = -Math.sin(rad) * this.speed;
        this.velZ = Math.cos(rad) * this.speed;

        this.setDeltaMovement(this.velX, this.getDeltaMovement().y - 0.08, this.velZ);
        this.move(net.minecraft.world.entity.MoverType.SELF, this.getDeltaMovement());

        // Gear calculation
        int kmh = getSpeedKmh();
        if (this.speed < -0.05) this.gear = 1; // R
        else if (kmh == 0) this.gear = 0; // P
        else if (kmh < 40) this.gear = 3; // D1
        else if (kmh < 90) this.gear = 4; // D2
        else if (kmh < 150) this.gear = 5; // D3
        else if (kmh < 220) this.gear = 6; // D4
        else if (kmh < 290) this.gear = 7; // D5
        else this.gear = 8; // D6

        // RPM
        this.rpm = 1200 + (float) ((kmh % 60) / 60.0 * 6500);

        this.wheelSpin += (float) (this.speed * 4.0);
    }

    private void runAutopilot() {
        // Simple radar and lane-keep
        Vec3 forward = Vec3.directionFromRotation(0, this.getYRot());
        Vec3 checkPos = this.position().add(forward.scale(6.0));
        
        // Scan for obstacles
        AABB box = new AABB(checkPos.x - 2, checkPos.y - 1, checkPos.z - 2, checkPos.x + 2, checkPos.y + 3, checkPos.z + 2);
        List<Entity> obstacles = this.level().getEntities(this, box, e -> e instanceof LivingEntity && !(e instanceof Player));
        if (!obstacles.isEmpty()) {
            // Auto brake!
            this.speed = Math.max(0, this.speed - 0.08);
            this.braking = true;
        } else {
            // Cruise along at moderate speed (70 km/h)
            double targetSpeed = 1.0;
            if (this.speed < targetSpeed) this.speed += 0.02;
            else this.speed *= 0.98;
        }
    }

    @Override
    public void positionRider(Entity passenger, MoveFunction moveFunc) {
        if (!this.hasPassenger(passenger)) return;

        int index = this.getPassengers().indexOf(passenger);
        // Driver on left (-0.40), Passenger on right (+0.40)
        double offsetX = (index == 0) ? -0.40 : 0.40;
        // Seating height: Lowered into cockpit (0.08) so head is under roof and legs inside footwell!
        double offsetY = 0.08;
        double offsetZ = -0.15;

        float yawRad = (float) Math.toRadians(this.getYRot());
        double cos = Math.cos(yawRad);
        double sin = Math.sin(yawRad);

        double worldX = this.getX() + (offsetX * cos - offsetZ * sin);
        double worldY = this.getY() + offsetY;
        double worldZ = this.getZ() + (offsetX * sin + offsetZ * cos);

        moveFunc.accept(passenger, worldX, worldY, worldZ);
        passenger.setYRot(passenger.getYRot() + (this.getYRot() - this.yRotO));
    }

    @Override
    public LivingEntity getControllingPassenger() {
        Entity first = this.getFirstPassenger();
        return first instanceof LivingEntity le ? le : null;
    }

    @Override
    public boolean isPickable() { return true; }
    @Override
    public boolean canBeCollidedWith() { return true; }
    @Override
    public boolean isPushable() { return false; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source)) return false;
        if (!this.level().isClientSide && !this.isRemoved()) {
            if (source.getEntity() instanceof Player p && p.isCreative()) {
                this.discard();
                return true;
            }
            if (source.getEntity() instanceof Player && !isShowroomCar()) {
                this.spawnAtLocation(new ItemStack(ModItems.SUPERCAR_VELOCE.get()));
                this.discard();
                return true;
            }
        }
        return true;
    }

    private void playLocalSound(SoundEvent sound, float vol, float pitch) {
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), sound, SoundSource.PLAYERS, vol, pitch);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        this.setVariant(SupercarVariant.byOrdinal(tag.getInt("Variant")));
        this.setLocked(tag.getBoolean("Locked"));
        this.setDriveMode(tag.getInt("DriveMode"));
        this.setOwned(tag.getBoolean("Owned"), tag.getString("Owner"));
        this.setShowroom(tag.getBoolean("Showroom"), tag.getBoolean("Turntable"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Variant", getVariant().ordinal());
        tag.putBoolean("Locked", isLocked());
        tag.putInt("DriveMode", getDriveMode());
        tag.putBoolean("Owned", isOwned());
        tag.putString("Owner", getOwnerName());
        tag.putBoolean("Showroom", isShowroomCar());
        tag.putBoolean("Turntable", this.entityData.get(DATA_TURNTABLE));
    }
}
