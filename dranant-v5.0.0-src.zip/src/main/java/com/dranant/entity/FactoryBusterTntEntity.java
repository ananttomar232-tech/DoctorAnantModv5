package com.dranant.entity;

import com.dranant.registry.ModEntities;
import com.dranant.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.List;

public class FactoryBusterTntEntity extends Entity {
    private int fuse = 80;

    public FactoryBusterTntEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    public FactoryBusterTntEntity(Level level, double x, double y, double z) {
        this(ModEntities.FACTORY_BUSTER_TNT.get(), level);
        this.setPos(x, y, z);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public void tick() {
        super.tick();
        this.fuse--;
        if (this.fuse <= 0) {
            this.discard();
            if (!this.level().isClientSide) {
                explode();
            }
        } else {
            if (this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SMOKE, this.getX(), this.getY() + 1.0, this.getZ(), 2, 0.1, 0.1, 0.1, 0.05);
            }
        }
    }

    private void explode() {
        int radius = 25;
        BlockPos center = this.blockPosition();
        
        // Sound and major explosion particles
        this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.FACTORY_EXPLOSION.get(), SoundSource.BLOCKS, 4.0F, 0.9F);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.EXPLOSION_EMITTER, this.getX(), this.getY() + 1.0, this.getZ(), 5, 1.0, 1.0, 1.0, 0.1);
        }

        // Damage hostile factory creatures & guards
        List<LivingEntity> enemies = this.level().getEntitiesOfClass(LivingEntity.class, new AABB(center).inflate(radius),
                e -> e instanceof FactoryGuardEntity || e instanceof MutantBloodBeastEntity);
        for (LivingEntity e : enemies) {
            e.hurt(this.damageSources().explosion(this, null), 300.0F);
        }

        // Selectively destroy ONLY factory structure blocks (Concrete, Iron bars, stained glass, redstone lamps, etc.)
        // Never destroy natural terrain (Grass, Dirt, Stone, Bedrock, Water) or player clinic blocks!
        for (int x = -radius; x <= radius; x++) {
            for (int y = -10; y <= 25; y++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x * x + z * z <= radius * radius) {
                        BlockPos p = center.offset(x, y, z);
                        BlockState state = this.level().getBlockState(p);
                        if (isFactoryBlock(state)) {
                            this.level().setBlock(p, Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            }
        }
    }

    private boolean isFactoryBlock(BlockState state) {
        return state.is(Blocks.GRAY_CONCRETE) || state.is(Blocks.BLACK_CONCRETE) ||
               state.is(Blocks.RED_CONCRETE) || state.is(Blocks.IRON_BARS) ||
               state.is(Blocks.RED_STAINED_GLASS) || state.is(Blocks.IRON_BLOCK) ||
               state.is(Blocks.REDSTONE_LAMP) || state.is(Blocks.HEAVY_WEIGHTED_PRESSURE_PLATE) ||
               state.is(Blocks.POLISHED_BLACKSTONE);
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) { this.fuse = tag.getInt("Fuse"); }
    @Override protected void addAdditionalSaveData(CompoundTag tag) { tag.putInt("Fuse", this.fuse); }
}
