package com.dranant.entity;

import com.dranant.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.List;

public class CityTrafficVehicleEntity extends Entity {
    public double speed = 0.55; // Steady city driving speed
    public float wheelSpin = 0.0F;
    private DriverVillagerEntity driver;

    public CityTrafficVehicleEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide) {
            // Spawn / retain driver villager
            if (this.getPassengers().isEmpty()) {
                DriverVillagerEntity d = new DriverVillagerEntity(ModEntities.DRIVER_VILLAGER.get(), this.level());
                d.setPos(this.getX(), this.getY(), this.getZ());
                this.level().addFreshEntity(d);
                d.startRiding(this);
            }

            // AI Navigation: follow road and avoid collisions
            Vec3 forward = Vec3.directionFromRotation(0, this.getYRot());
            Vec3 checkPoint = this.position().add(forward.scale(5.0));

            AABB obstacleBox = new AABB(checkPoint.x - 1.5, checkPoint.y, checkPoint.z - 1.5, checkPoint.x + 1.5, checkPoint.y + 2, checkPoint.z + 1.5);
            List<Entity> obstacles = this.level().getEntities(this, obstacleBox, e -> e instanceof LivingEntity || e instanceof SupercarEntity);

            if (!obstacles.isEmpty()) {
                // Brake!
                this.speed = Math.max(0.0, this.speed - 0.05);
            } else {
                this.speed = Math.min(0.65, this.speed + 0.02);
            }

            // Road edge check & gentle steering
            BlockPos belowFront = BlockPos.containing(checkPoint.x, this.getY() - 1, checkPoint.z);
            BlockState road = this.level().getBlockState(belowFront);
            if (!road.is(Blocks.BLACK_CONCRETE) && !road.is(Blocks.GRAY_CONCRETE) && !road.is(Blocks.SMOOTH_STONE)) {
                // Gently steer towards road
                this.setYRot(this.getYRot() + 15.0F);
            }

            double rad = Math.toRadians(this.getYRot());
            this.setDeltaMovement(-Math.sin(rad) * this.speed, this.getDeltaMovement().y - 0.08, Math.cos(rad) * this.speed);
            this.move(net.minecraft.world.entity.MoverType.SELF, this.getDeltaMovement());
        }

        this.wheelSpin += (float)(this.speed * 4.0);
    }

    @Override
    public void positionRider(Entity passenger, MoveFunction moveFunc) {
        if (!this.hasPassenger(passenger)) return;
        moveFunc.accept(passenger, this.getX(), this.getY() + 0.25, this.getZ());
    }

    @Override public boolean isPickable() { return true; }
    @Override public boolean canBeCollidedWith() { return true; }
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
}
