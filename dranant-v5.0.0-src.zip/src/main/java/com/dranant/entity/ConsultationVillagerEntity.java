package com.dranant.entity;

import com.dranant.dialogue.Speech;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class ConsultationVillagerEntity extends PathfinderMob {
    private int speechCooldown = 60;
    private static final String[] COMPLAINTS = {
        "Doctor sahab, bukhar 3 din se nahi utar raha!",
        "Sir mein bahut dard hai bhaiya... koi achhi dawai do!",
        "Pahad se gir gaya, poora body dard kar raha hai!",
        "Dr. Anant ka formula hi bacha sakta hai mujhe!",
        "Pet mein ajeeb si aawazein aa rahi hain doctor saab!"
    };

    public ConsultationVillagerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCustomName(net.minecraft.network.chat.Component.literal("Consultation Patient"));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0); // Stationary at desk
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new LookAtPlayerGoal(this, Player.class, 8.0F));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (this.speechCooldown > 0) {
                this.speechCooldown--;
            } else {
                this.speechCooldown = 120 + this.random.nextInt(80);
                String msg = COMPLAINTS[this.random.nextInt(COMPLAINTS.length)];
                Speech.say(this, msg);
            }
        }
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide) {
            Speech.say(this, "Aap hi Dr. Anant ho na? Jaldi dekho mujhe!");
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }
}
