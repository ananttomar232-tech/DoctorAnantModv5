package com.dranant.entity;

import com.dranant.registry.ModEntities;
import java.util.UUID;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class SidekickEntity extends PathfinderMob {
    private static final EntityDataAccessor<Boolean> DATA_SHOOTING = SynchedEntityData.defineId(SidekickEntity.class, EntityDataSerializers.BOOLEAN);
    private UUID ownerId = null;

    public SidekickEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 100.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 10.0);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_SHOOTING, false);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(2, new ShootGoal(this));
        this.goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 8.0f));
        this.goalSelector.addGoal(9, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new NearestAttackableTargetGoal<>(this, FactoryGuardEntity.class, true));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, MutantBloodBeastEntity.class, true));
    }

    public UUID getOwnerId() { return ownerId; }
    public void setOwner(Player player) { this.ownerId = player.getUUID(); }
    public boolean isShooting() { return this.entityData.get(DATA_SHOOTING); }

    static class ShootGoal extends Goal {
        private final SidekickEntity sidekick;
        private int cooldown = 0;

        public ShootGoal(SidekickEntity sidekick) { this.sidekick = sidekick; }
        @Override
        public boolean canUse() { return sidekick.getTarget() != null && sidekick.getTarget().isAlive(); }
        @Override
        public void tick() {
            LivingEntity target = sidekick.getTarget();
            if (target != null && --cooldown <= 0) {
                cooldown = 15;
                SidekickBulletEntity bullet = new SidekickBulletEntity(sidekick.level(), sidekick);
                double dx = target.getX() - sidekick.getX();
                double dy = target.getEyeY() - bullet.getY();
                double dz = target.getZ() - sidekick.getZ();
                bullet.shoot(dx, dy, dz, 1.8f, 1.0f);
                sidekick.level().addFreshEntity(bullet);
            }
        }
    }
}
