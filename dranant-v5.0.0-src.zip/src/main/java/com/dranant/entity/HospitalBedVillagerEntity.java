package com.dranant.entity;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;

public class HospitalBedVillagerEntity extends PathfinderMob {
    public HospitalBedVillagerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setCustomName(net.minecraft.network.chat.Component.literal("Inpatient Villager"));
        this.setPose(Pose.SLEEPING);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.0);
    }

    @Override
    public void tick() {
        super.tick();
        this.setPose(Pose.SLEEPING);
        if (this.level() instanceof ServerLevel sl && this.tickCount % 40 == 0) {
            sl.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.6, this.getZ(), 1, 0.2, 0.2, 0.2, 0.01);
        }
    }
}
