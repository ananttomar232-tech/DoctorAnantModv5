package com.dranant.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class ShopkeeperEntity extends AssistantEntity {
    public ShopkeeperEntity(EntityType<? extends AssistantEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public String greeting(Player player) {
        return "Aao bhai aao! Best deals sirf yahin milengi!";
    }
}
