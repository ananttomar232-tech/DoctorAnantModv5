package com.dranant.entity;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class SeatEntity extends Entity {
    private BlockPos sourcePos;

    public SeatEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
    }

    public static void sit(Level level, BlockPos pos, Player player, double yOffset, Direction facing) {
        if (level.isClientSide) return;
        if (!level.getEntitiesOfClass(SeatEntity.class, new AABB(pos)).isEmpty()) return;

        SeatEntity seat = new SeatEntity(com.dranant.registry.ModEntities.SEAT.get(), level);
        seat.setPos(pos.getX() + 0.5, pos.getY() + yOffset, pos.getZ() + 0.5);
        seat.setYRot(facing != null ? facing.toYRot() : player.getYRot());
        seat.sourcePos = pos;
        level.addFreshEntity(seat);
        player.startRiding(seat);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (this.getPassengers().isEmpty() || this.sourcePos == null || this.level().isEmptyBlock(this.sourcePos)) {
                this.discard();
            }
        }
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        return this.sourcePos != null ? Vec3.atCenterOf(this.sourcePos.above()) : super.getDismountLocationForPassenger(passenger);
    }

    @Override protected void defineSynchedData(SynchedEntityData.Builder builder) {}
    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
}
