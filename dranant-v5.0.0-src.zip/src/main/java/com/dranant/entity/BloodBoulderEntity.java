package com.dranant.entity;

import com.dranant.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;

public class BloodBoulderEntity extends ThrowableItemProjectile {
    public BloodBoulderEntity(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public BloodBoulderEntity(Level level, LivingEntity shooter) {
        super(ModEntities.BLOOD_BOULDER.get(), shooter, level);
    }

    @Override
    protected Item getDefaultItem() { return Items.RED_TERRACOTTA; }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.LAVA, this.getX(), this.getY(), this.getZ(), 20, 0.5, 0.5, 0.5, 0.1);
            sl.explode(this, this.getX(), this.getY(), this.getZ(), 2.0f, Level.ExplosionInteraction.NONE);
        }
        if (!this.level().isClientSide()) this.discard();
    }
}
