package com.dranant.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class AssistantScientistEntity extends AssistantEntity {
    public AssistantScientistEntity(EntityType<? extends AssistantEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public String greeting(Player player) {
        return "Doctor saab! Lab mein naye experiments taiyar hain!";
    }
}
