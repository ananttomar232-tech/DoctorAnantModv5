package com.dranant.entity.ai;

import com.dranant.entity.MutantBloodBeastEntity;

public class BloodGeyserGoal extends BossAbilityGoal {
    public BloodGeyserGoal(MutantBloodBeastEntity beast) { super(beast); }
}
