package com.dranant.entity.ai;

import com.dranant.entity.MutantBloodBeastEntity;

public class GroundCrackSlamGoal extends BossAbilityGoal {
    public GroundCrackSlamGoal(MutantBloodBeastEntity beast) { super(beast); }
}
