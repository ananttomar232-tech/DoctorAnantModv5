package com.dranant.entity.ai;

public class BossAbilities {
    public static final boolean ROOTED = false;
}
