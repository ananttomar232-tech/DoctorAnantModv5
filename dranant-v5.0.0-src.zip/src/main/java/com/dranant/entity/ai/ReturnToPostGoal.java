package com.dranant.entity.ai;

import com.dranant.entity.AssistantEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;

public class ReturnToPostGoal extends Goal {
    private final AssistantEntity mob;

    public ReturnToPostGoal(AssistantEntity mob) { this.mob = mob; }

    @Override
    public boolean canUse() {
        BlockPos post = mob.getPost();
        return post != null && mob.blockPosition().distSqr(post) > 16.0;
    }

    @Override
    public void tick() {
        BlockPos post = mob.getPost();
        if (post != null) {
            mob.getNavigation().moveTo(post.getX() + 0.5, post.getY(), post.getZ() + 0.5, 1.0);
        }
    }
}
