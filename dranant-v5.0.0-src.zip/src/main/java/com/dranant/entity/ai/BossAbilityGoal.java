package com.dranant.entity.ai;

import com.dranant.entity.MutantBloodBeastEntity;
import net.minecraft.world.entity.ai.goal.Goal;

public class BossAbilityGoal extends Goal {
    protected final MutantBloodBeastEntity beast;

    public BossAbilityGoal(MutantBloodBeastEntity beast) { this.beast = beast; }
    @Override
    public boolean canUse() { return beast.getTarget() != null && beast.getTarget().isAlive(); }
}
