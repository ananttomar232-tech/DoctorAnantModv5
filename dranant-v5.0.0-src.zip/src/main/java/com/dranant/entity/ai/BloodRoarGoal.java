package com.dranant.entity.ai;

import com.dranant.entity.MutantBloodBeastEntity;

public class BloodRoarGoal extends BossAbilityGoal {
    public BloodRoarGoal(MutantBloodBeastEntity beast) { super(beast); }
}
