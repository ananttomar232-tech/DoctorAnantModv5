package com.dranant.entity.ai;

import com.dranant.entity.MutantBloodBeastEntity;

public class BloodChargeGoal extends BossAbilityGoal {
    public BloodChargeGoal(MutantBloodBeastEntity beast) { super(beast); }
}
