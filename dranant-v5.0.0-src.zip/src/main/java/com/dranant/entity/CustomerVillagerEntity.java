package com.dranant.entity;

import com.dranant.counter.DiamondBank;
import com.dranant.dialogue.Speech;
import com.dranant.registry.ModItems;
import com.dranant.registry.ModSounds;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

public class CustomerVillagerEntity extends PathfinderMob {
    private int purchaseCooldown = 100;

    public CustomerVillagerEntity(EntityType<? extends PathfinderMob> type, Level level) {
        super(type, level);
        this.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(Items.DIAMOND));
        this.setCustomName(net.minecraft.network.chat.Component.literal("Customer Villager"));
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0)
                .add(Attributes.MOVEMENT_SPEED, 0.23);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new FloatGoal(this));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 6.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide) {
            if (this.purchaseCooldown > 0) {
                this.purchaseCooldown--;
                if (this.purchaseCooldown == 0) {
                    // Pay diamonds to clinic counter
                    DiamondBank.add(this.level(), 5);
                    this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.CASH_REGISTER_CHIME.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
                    Speech.say(this, "Dr. Anant zindabad! Ye lo payment 5 diamonds.");
                    this.setItemInHand(InteractionHand.MAIN_HAND, new ItemStack(ModItems.FEVER_SYRUP.get()));
                }
            }
        }
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (!this.level().isClientSide) {
            Speech.say(this, "Doctor sahab ki dawai lene aaya hoon!");
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }
}
