package com.dranant.entity;

import com.dranant.registry.ModItems;
import com.dranant.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class BikeEntity extends Entity {
    public static final double MAX_SPEED = 2.4;
    public static final double BOOST_SPEED = 3.2;

    public double speed = 0.0;
    public float turnInput = 0.0F;
    public double velX = 0.0;
    public double velZ = 0.0;
    public double turbo = 1.0;
    public boolean boosting = false;
    public int gear = 1;
    public float rpm = 1500.0F;
    public float slide = 0.0F;
    public float wheelRot = 0.0F;
    public float wheelRotO = 0.0F;
    public float lean = 0.0F;
    public float wheelie = 0.0F;

    public BikeEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {}

    public int getSpeedKmh() {
        return (int) Math.round(Math.abs(this.speed) * 72.0);
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (!this.level().isClientSide) {
            if (this.getPassengers().isEmpty()) {
                player.startRiding(this);
                this.level().playSound(null, this.getX(), this.getY(), this.getZ(), ModSounds.BIKE_ENGINE.get(), SoundSource.PLAYERS, 1.0F, 1.0F);
                return InteractionResult.SUCCESS;
            }
        }
        return InteractionResult.sidedSuccess(this.level().isClientSide);
    }

    @Override
    public void tick() {
        super.tick();
        this.wheelRotO = this.wheelRot;

        LivingEntity rider = getControllingPassenger();
        if (rider instanceof Player player) {
            float forwardInput = player.zza;
            // FIX: Negate player.xxa so turning Right turns Right, and turning Left turns Left!
            float steerInput = -player.xxa;
            boolean space = player.jumping;

            double accel = 0.045;
            double top = space ? BOOST_SPEED : MAX_SPEED;

            if (forwardInput > 0) {
                this.speed = Math.min(top, this.speed + accel);
                if (space && this.speed > 0.6) {
                    this.wheelie = Mth.lerp(0.2F, this.wheelie, 28.0F);
                } else {
                    this.wheelie = Mth.lerp(0.2F, this.wheelie, 0.0F);
                }
            } else if (forwardInput < 0) {
                this.speed = Math.max(-0.4, this.speed - accel * 1.5);
                this.wheelie = Mth.lerp(0.3F, this.wheelie, 0.0F);
            } else {
                this.speed *= 0.95;
                this.wheelie = Mth.lerp(0.3F, this.wheelie, 0.0F);
            }

            // Turning & Lean Physics
            if (Math.abs(this.speed) > 0.02) {
                float yawChange = steerInput * 3.8F * (float) Math.signum(this.speed);
                this.setYRot(this.getYRot() + yawChange);
                // Dynamic motorcycle lean into corners
                this.lean = Mth.lerp(0.25F, this.lean, -steerInput * (float)(Math.abs(this.speed) / MAX_SPEED) * 35.0F);
            } else {
                this.lean = Mth.lerp(0.2F, this.lean, 0.0F);
            }

            double rad = Math.toRadians(this.getYRot());
            this.velX = -Math.sin(rad) * this.speed;
            this.velZ = Math.cos(rad) * this.speed;

            this.setDeltaMovement(this.velX, this.getDeltaMovement().y - 0.08, this.velZ);
            this.move(net.minecraft.world.entity.MoverType.SELF, this.getDeltaMovement());

            this.wheelRot += (float)(this.speed * 4.5);
            this.rpm = 2000 + (float)((getSpeedKmh() % 50) / 50.0 * 11000);
        } else {
            this.speed *= 0.85;
            this.lean = Mth.lerp(0.2F, this.lean, 0.0F);
            this.wheelie = Mth.lerp(0.2F, this.wheelie, 0.0F);
        }
    }

    @Override
    public void positionRider(Entity passenger, MoveFunction moveFunc) {
        if (!this.hasPassenger(passenger)) return;
        double rad = Math.toRadians(this.getYRot());
        double x = this.getX() - Math.sin(rad) * -0.2;
        double y = this.getY() + 0.35 + (this.wheelie > 5 ? 0.2 : 0);
        double z = this.getZ() + Math.cos(rad) * -0.2;
        moveFunc.accept(passenger, x, y, z);
    }

    @Override
    public LivingEntity getControllingPassenger() {
        Entity first = this.getFirstPassenger();
        return first instanceof LivingEntity le ? le : null;
    }

    @Override
    public boolean isPickable() { return true; }
    @Override
    public boolean canBeCollidedWith() { return true; }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source)) return false;
        if (!this.level().isClientSide && !this.isRemoved()) {
            this.spawnAtLocation(new ItemStack(ModItems.DR_ANANT_BIKE.get()));
            this.discard();
        }
        return true;
    }

    @Override protected void readAdditionalSaveData(CompoundTag tag) {}
    @Override protected void addAdditionalSaveData(CompoundTag tag) {}
}
