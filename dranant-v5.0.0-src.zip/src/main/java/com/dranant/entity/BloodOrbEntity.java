package com.dranant.entity;

import com.dranant.registry.ModEntities;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;

public class BloodOrbEntity extends ThrowableItemProjectile {
    public BloodOrbEntity(EntityType<? extends ThrowableItemProjectile> type, Level level) {
        super(type, level);
    }

    public BloodOrbEntity(Level level, LivingEntity shooter) {
        super(ModEntities.BLOOD_ORB.get(), shooter, level);
    }

    @Override
    protected Item getDefaultItem() { return Items.MAGMA_CREAM; }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity e = result.getEntity();
        if (e != this.getOwner() && e instanceof LivingEntity le) {
            le.hurt(this.damageSources().thrown(this, this.getOwner()), 10.0f);
        }
        if (!this.level().isClientSide()) this.discard();
    }
}
