package com.dranant.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class AssistantPharmacistEntity extends AssistantEntity {
    public AssistantPharmacistEntity(EntityType<? extends AssistantEntity> type, Level level) {
        super(type, level);
    }

    @Override
    public String greeting(Player player) {
        return "Namaste " + player.getName().getString() + "! Dawai chahiye kya?";
    }
}
