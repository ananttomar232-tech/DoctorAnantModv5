package com.dranant.clinic;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;

public class ClinicRegistry {
    public record ClinicEntry(BlockPos pos, int tier) {}
    private static final List<ClinicEntry> CLINICS = new ArrayList<>();

    public static synchronized void add(BlockPos pos, int tier) {
        CLINICS.removeIf(c -> c.pos().equals(pos));
        CLINICS.add(new ClinicEntry(pos, tier));
    }

    public static synchronized void remove(BlockPos pos) {
        CLINICS.removeIf(c -> c.pos().equals(pos));
    }

    public static synchronized ClinicEntry nearest(BlockPos pos) {
        ClinicEntry best = null;
        double bestDist = Double.MAX_VALUE;
        for (ClinicEntry c : CLINICS) {
            double d = c.pos().distSqr(pos);
            if (d < bestDist) {
                bestDist = d;
                best = c;
            }
        }
        return best;
    }

    public static synchronized void clear() {
        CLINICS.clear();
    }
}
