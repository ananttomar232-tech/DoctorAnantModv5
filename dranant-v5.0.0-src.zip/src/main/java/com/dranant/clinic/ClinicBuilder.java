package com.dranant.clinic;

import com.dranant.block.ClinicSummonerBlock;
import com.dranant.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

public class ClinicBuilder {
    public record Plan(int tier, BlockPos origin, Rotation rotation) {}

    public static boolean summonInFront(ServerLevel level, Player player, int tier) {
        Direction dir = player.getDirection();
        BlockPos origin = player.blockPosition().relative(dir, 5);
        return summonAt(level, player, tier, origin);
    }

    public static boolean summonAt(ServerLevel level, Player player, int tier, BlockPos origin) {
        Rotation rot = Rotation.NONE;
        Plan plan = new Plan(tier, origin, rot);
        build(level, plan);
        ClinicRegistry.add(origin, tier);
        player.sendSystemMessage(Component.literal("§a[Dr. Anant Clinic] " + ClinicTiers.name(tier) + " constructed at " + origin.toShortString() + "!"));
        return true;
    }

    public static void build(ServerLevel level, Plan plan) {
        Frame frame = new Frame(plan.origin(), plan.rotation());
        Blueprint bp = new Blueprint(frame);

        int tier = plan.tier();
        int width = 7 + tier * 2;
        int length = 9 + tier * 2;
        int height = 5 + tier;

        // Base foundation
        bp.fill(-width / 2, -1, 0, width / 2, -1, length, Blocks.SMOOTH_QUARTZ.defaultBlockState());
        // Floor
        bp.fill(-width / 2, 0, 0, width / 2, 0, length, Blocks.LIGHT_BLUE_CONCRETE.defaultBlockState());

        // Walls
        for (int y = 1; y <= height; y++) {
            BlockState wall = (y == height) ? Blocks.CYAN_CONCRETE.defaultBlockState() : Blocks.WHITE_CONCRETE.defaultBlockState();
            // north/south walls
            for (int x = -width / 2; x <= width / 2; x++) {
                bp.set(x, y, 0, wall);
                bp.set(x, y, length, wall);
            }
            // east/west walls
            for (int z = 0; z <= length; z++) {
                bp.set(-width / 2, y, z, wall);
                bp.set(width / 2, y, z, wall);
            }
        }

        // Roof
        bp.fill(-width / 2, height + 1, 0, width / 2, height + 1, length, Blocks.SMOOTH_QUARTZ.defaultBlockState());
        // Sea lanterns for light
        bp.set(0, height, length / 2, Blocks.SEA_LANTERN.defaultBlockState());

        // Entrance door opening
        bp.set(0, 1, 0, Blocks.AIR.defaultBlockState());
        bp.set(0, 2, 0, Blocks.AIR.defaultBlockState());

        // Interior Facilities
        bp.after(sl -> {
            BlockPos regPos = frame.at(0, 1, 4);
            BuildHelper.placeRegister(sl, regPos, frame.dir(Direction.NORTH));
            BuildHelper.spawnPharmacist(sl, frame.at(0, 1, 5), frame.dir(Direction.NORTH));

            if (tier >= 2) {
                BuildHelper.spawnScientist(sl, frame.at(-2, 1, 5), frame.dir(Direction.EAST));
            }
        });

        ConstructionManager.build(level, bp);
    }
}
