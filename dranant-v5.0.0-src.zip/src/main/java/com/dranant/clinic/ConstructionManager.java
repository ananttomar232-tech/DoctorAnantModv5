package com.dranant.clinic;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class ConstructionManager {
    public static void build(ServerLevel level, Blueprint blueprint) {
        for (var entry : blueprint.blocks().entrySet()) {
            level.setBlock(entry.getKey(), entry.getValue(), 3);
        }
        for (var action : blueprint.afterBuild()) {
            action.accept(level);
        }
    }

    public static void erase(ServerLevel level, BlockPos origin, int radius, int height) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                for (int dy = 0; dy <= height; dy++) {
                    level.setBlock(origin.offset(dx, dy, dz), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
    }
}
