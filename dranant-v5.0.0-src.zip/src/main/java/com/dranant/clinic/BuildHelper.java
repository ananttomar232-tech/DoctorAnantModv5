package com.dranant.clinic;

import com.dranant.block.entity.DiamondCashRegisterBlockEntity;
import com.dranant.block.entity.ItemDisplayPedestalBlockEntity;
import com.dranant.entity.AssistantPharmacistEntity;
import com.dranant.entity.AssistantScientistEntity;
import com.dranant.entity.ShopkeeperEntity;
import com.dranant.registry.ModBlockEntities;
import com.dranant.registry.ModBlocks;
import com.dranant.registry.ModEntities;
import java.util.Random;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

public class BuildHelper {
    public static final String[] PHARMACIST_NAMES = {"Raju", "Pappu", "Chintu", "Golu"};
    public static final String[] SCIENTIST_NAMES = {"Dr. Bunty", "Dr. Monu", "Dr. Sonu", "Dr. Tinku"};
    public static final String[] SELLER_NAMES = {"Seth Ji", "Lala Ram", "Gupta Ji", "Mishra Ji"};
    private static final Random RAND = new Random();

    public static void placeRegister(ServerLevel level, BlockPos pos, Direction facing) {
        level.setBlock(pos, ModBlocks.DIAMOND_CASH_REGISTER.get().defaultBlockState().setValue(com.dranant.block.DiamondCashRegisterBlock.FACING, facing), 3);
    }

    public static void stockPedestal(ServerLevel level, BlockPos pos, ItemStack item, long price) {
        level.setBlock(pos, ModBlocks.ITEM_DISPLAY_PEDESTAL.get().defaultBlockState(), 3);
        if (level.getBlockEntity(pos) instanceof ItemDisplayPedestalBlockEntity be) {
            be.setItem(item);
            be.setPrice(price);
            be.setHovering(true); // Hover 360 degree enabled!
        }
    }

    public static void spawnPharmacist(ServerLevel level, BlockPos pos, Direction facing) {
        AssistantPharmacistEntity p = new AssistantPharmacistEntity(ModEntities.ASSISTANT_PHARMACIST.get(), level);
        p.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        p.setYRot(facing.toYRot());
        p.setCustomName(Component.literal("Pharmacist " + PHARMACIST_NAMES[RAND.nextInt(PHARMACIST_NAMES.length)]));
        p.setCustomNameVisible(true);
        level.addFreshEntity(p);
    }

    public static void spawnScientist(ServerLevel level, BlockPos pos, Direction facing) {
        AssistantScientistEntity s = new AssistantScientistEntity(ModEntities.ASSISTANT_SCIENTIST.get(), level);
        s.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        s.setYRot(facing.toYRot());
        s.setCustomName(Component.literal(SCIENTIST_NAMES[RAND.nextInt(SCIENTIST_NAMES.length)]));
        s.setCustomNameVisible(true);
        level.addFreshEntity(s);
    }

    public static void spawnShopkeeper(ServerLevel level, BlockPos pos, Direction facing) {
        ShopkeeperEntity sk = new ShopkeeperEntity(ModEntities.SHOPKEEPER.get(), level);
        sk.setPos(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
        sk.setYRot(facing.toYRot());
        sk.setCustomName(Component.literal(SELLER_NAMES[RAND.nextInt(SELLER_NAMES.length)]));
        sk.setCustomNameVisible(true);
        level.addFreshEntity(sk);
    }
}
