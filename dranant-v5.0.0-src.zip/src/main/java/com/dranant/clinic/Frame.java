package com.dranant.clinic;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.block.Rotation;
import net.minecraft.world.level.block.state.BlockState;

public record Frame(BlockPos origin, Rotation rotation) {
    public BlockPos at(int x, int y, int z) {
        BlockPos rel = new BlockPos(x, y, z).rotate(rotation);
        return origin.offset(rel);
    }

    public Direction dir(Direction d) {
        return rotation.rotate(d);
    }

    public BlockState state(BlockState s) {
        return s.rotate(rotation);
    }

    public float yaw(float baseYaw) {
        return switch (rotation) {
            case CLOCKWISE_90 -> baseYaw + 90.0f;
            case CLOCKWISE_180 -> baseYaw + 180.0f;
            case COUNTERCLOCKWISE_90 -> baseYaw + 270.0f;
            default -> baseYaw;
        };
    }
}
