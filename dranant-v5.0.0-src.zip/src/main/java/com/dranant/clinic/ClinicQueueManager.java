package com.dranant.clinic;

import com.dranant.block.entity.DiamondCashRegisterBlockEntity;
import com.dranant.counter.DiamondBank;
import com.dranant.counter.DiamondFx;
import com.dranant.dialogue.Lines;
import com.dranant.dialogue.Speech;
import com.dranant.entity.CustomerVillagerEntity;
import com.dranant.entity.PatientVillagerEntity;
import com.dranant.registry.ModEntities;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.Villager;

public class ClinicQueueManager {
    public static void tick(ServerLevel level, DiamondCashRegisterBlockEntity register) {
        // Spawn and manage patient lines
    }

    public static void handlePurchase(ServerLevel level, BlockPos pos, long diamonds) {
        DiamondBank bank = DiamondBank.get(level.getServer());
        bank.add(diamonds, level.getServer());
        DiamondFx.burst(level, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5);
    }
}
