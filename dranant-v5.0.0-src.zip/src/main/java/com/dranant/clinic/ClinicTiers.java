package com.dranant.clinic;

public class ClinicTiers {
    public static final int MAX_TIER = 6;
    public static final String[] NAMES = {
        "Village Dispensary",
        "Community Clinic",
        "Health Centre",
        "City Hospital",
        "Medical College",
        "Mega Hospital"
    };

    public static final long[] PRICES = {
        0L,
        250L,
        750L,
        2000L,
        5000L,
        15000L
    };

    public static String name(int tier) {
        return NAMES[clamp(tier) - 1];
    }

    public static long price(int tier) {
        return PRICES[clamp(tier) - 1];
    }

    public static String structureName(int tier) {
        return "clinic_level_" + clamp(tier);
    }

    public static int clamp(int tier) {
        return Math.max(1, Math.min(MAX_TIER, tier));
    }
}
