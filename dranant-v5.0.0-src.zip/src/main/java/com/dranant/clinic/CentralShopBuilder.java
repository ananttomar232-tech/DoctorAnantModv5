package com.dranant.clinic;

import com.dranant.registry.ModBlocks;
import com.dranant.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Rotation;

public class CentralShopBuilder {
    public static void build(ServerLevel level, BlockPos origin, Player player) {
        buildAt(level, origin, Rotation.NONE, player);
    }

    public static void buildAt(ServerLevel level, BlockPos origin, Rotation rot, Player player) {
        Frame frame = new Frame(origin, rot);
        Blueprint bp = new Blueprint(frame);

        // Shop pavilion
        bp.fill(-5, 0, -5, 5, 0, 5, Blocks.POLISHED_ANDESITE.defaultBlockState());
        bp.fill(-5, 1, -5, 5, 4, 5, Blocks.AIR.defaultBlockState());

        // Quartz pillars
        bp.fill(-4, 1, -4, -4, 3, -4, Blocks.QUARTZ_PILLAR.defaultBlockState());
        bp.fill(4, 1, -4, 4, 3, -4, Blocks.QUARTZ_PILLAR.defaultBlockState());
        bp.fill(-4, 1, 4, -4, 3, 4, Blocks.QUARTZ_PILLAR.defaultBlockState());
        bp.fill(4, 1, 4, 4, 3, 4, Blocks.QUARTZ_PILLAR.defaultBlockState());

        // Roof
        bp.fill(-5, 4, -5, 5, 4, 5, Blocks.YELLOW_CONCRETE.defaultBlockState());
        bp.set(0, 4, 0, Blocks.SEA_LANTERN.defaultBlockState());

        // Shopkeeper and Pedestals
        bp.after(sl -> {
            BuildHelper.spawnShopkeeper(sl, frame.at(0, 1, 0), frame.dir(Direction.SOUTH));

            // Stock Shop items on hovering 360 pedestals:
            // 1. Factory Buster TNT (Selective factory demolition TNT)
            BuildHelper.stockPedestal(sl, frame.at(-2, 1, -2), new ItemStack(ModBlocks.FACTORY_BUSTER_TNT.get()), 25);
            // 2. Heavy Machine Gun
            BuildHelper.stockPedestal(sl, frame.at(2, 1, -2), new ItemStack(ModItems.HEAVY_MACHINE_GUN.get()), 40);
            // 3. Sci-Fi M254 Rifle
            BuildHelper.stockPedestal(sl, frame.at(-2, 1, 2), new ItemStack(ModItems.SCIFI_M254_RIFLE.get()), 50);
            // 4. Plasma Rifle
            BuildHelper.stockPedestal(sl, frame.at(2, 1, 2), new ItemStack(ModItems.PLASMA_RIFLE.get()), 30);
            // 5. Immortality Medicine Tier 4
            BuildHelper.stockPedestal(sl, frame.at(0, 1, 3), new ItemStack(ModItems.MEDICINE_4.get()), 20);
        });

        ConstructionManager.build(level, bp);
        if (player != null) {
            player.sendSystemMessage(Component.literal("§6[Central Shop] Central diamond marketplace constructed!"));
        }
    }
}
