package com.dranant.clinic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.state.BlockState;

public class Blueprint {
    private final Frame frame;
    private final Map<BlockPos, BlockState> blocks = new HashMap<>();
    private final List<Consumer<ServerLevel>> afterBuild = new ArrayList<>();

    public Blueprint(Frame frame) {
        this.frame = frame;
    }

    public Frame frame() { return frame; }
    public Map<BlockPos, BlockState> blocks() { return blocks; }
    public List<Consumer<ServerLevel>> afterBuild() { return afterBuild; }

    public Blueprint set(int x, int y, int z, BlockState state) {
        blocks.put(frame.at(x, y, z), frame.state(state));
        return this;
    }

    public Blueprint fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                    set(x, y, z, state);
                }
            }
        }
        return this;
    }

    public Blueprint after(Consumer<ServerLevel> action) {
        afterBuild.add(action);
        return this;
    }
}
