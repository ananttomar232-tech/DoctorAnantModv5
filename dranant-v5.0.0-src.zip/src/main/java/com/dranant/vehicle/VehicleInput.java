package com.dranant.vehicle;

public record VehicleInput(float forward, float steer, boolean space, boolean shift, boolean horn, boolean headlights, boolean doors, boolean hood, boolean trunk, boolean nitro, boolean lock, boolean wipers, boolean roof, boolean autopilot, boolean modeSwitch) {
}
