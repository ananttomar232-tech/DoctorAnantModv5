package com.dranant.config;

import net.neoforged.neoforge.common.ModConfigSpec;

public class DrAnantConfig {
    public static final ModConfigSpec SPEC;
    public static final ModConfigSpec.BooleanValue ENABLE_TRAFFIC;
    public static final ModConfigSpec.IntValue SUPERCAR_BASE_SPEED;
    public static final ModConfigSpec.BooleanValue MUTANT_FACTORY_SPAWN;

    static {
        ModConfigSpec.Builder builder = new ModConfigSpec.Builder();
        builder.push("general");
        ENABLE_TRAFFIC = builder.comment("Enable AI Traffic Vehicles in Dr. Anant City").define("enableTraffic", true);
        SUPERCAR_BASE_SPEED = builder.comment("Base Supercar Max Speed in km/h").defineInRange("supercarMaxSpeed", 360, 100, 600);
        MUTANT_FACTORY_SPAWN = builder.comment("Spawn Mutant Blood Beast Factory in City outskirts").define("mutantFactorySpawn", true);
        builder.pop();
        SPEC = builder.build();
    }
}
