package com.dranant.util;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

public class TimedEntityRemover {
    public static void scheduleRemoval(Entity entity, int ticks) {
        if (entity.level() instanceof ServerLevel level) {
            // tag entity with removal tick
            entity.addTag("dranant_timer_" + (level.getGameTime() + ticks));
        }
    }
}
