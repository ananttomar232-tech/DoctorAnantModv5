@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
    gradle %*
) else (
    echo Gradle not found in PATH, running gradle...
    gradle %*
)
